package com.vsmart.farmengineer.activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.Base64;
import com.loopj.android.http.RequestParams;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.adapters.NothingSelectedSpinnerAdapter;
import com.vsmart.farmengineer.utils.PrefManager;
import com.vsmart.farmengineer.utils.Urls;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import cz.msebera.android.httpclient.Header;

public class AddProducts extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener  {

    Spinner brandSpinner, modelSpinner;
    String brandNameString, brandNameStringValue, modelString, modelStringValue;
    ProgressDialog progress;
    TextInputLayout text_input_location, text_input_landMark, text_input_Hours, text_input_Year, text_input_Price, text_input_RegistrationNo;
    TextInputEditText locationEditText, landmarkEditText, hoursEditText, yearEditText, priceEditText, registationEditText;
    LinearLayout imageUpload;
    ImageView imagePreview;
    AppCompatButton btnSubmit;
    private static final int CAMERA_REQUEST = 1888;
    private static final int PICTURE_TAKEN_FROM_GALLERY = 999;
    String img = null;
    Uri selectedImage;
    ProgressDialog progressDialog;
    String imageType;
    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 2;
    String mimeType = null;
    String productTypeID,feCatID;

    String lat, lang,address;
    GoogleApiClient mGoogleApiClient;
    LocationRequest mLocationRequest;
    String msg;
    Toolbar toolbar;
    LinearLayout hoursLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_products);


        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_white_24);


        hoursLayout = findViewById(R.id.hoursLayout);
        //spinner ids
        brandSpinner = findViewById(R.id.brandSpinner);
        modelSpinner = findViewById(R.id.modelSpinner);
     //   productsSpinner = findViewById(R.id.productsSpinner);

        //TextInputLayout ids
        text_input_location = findViewById(R.id.text_input_location);
        text_input_landMark = findViewById(R.id.text_input_landMark);
        text_input_Hours = findViewById(R.id.text_input_Hours);
     //   text_input_Month = findViewById(R.id.text_input_Month);
        text_input_Year = findViewById(R.id.text_input_Year);
        text_input_Price = findViewById(R.id.text_input_Price);
        text_input_RegistrationNo = findViewById(R.id.text_input_RegistrationNo);

        //TextInputEditText ids
        locationEditText = findViewById(R.id.locationEditText);
        landmarkEditText = findViewById(R.id.landmarkEditText);
        hoursEditText = findViewById(R.id.hoursEditText);
      //  monthEditText = findViewById(R.id.monthEditText);
        yearEditText = findViewById(R.id.yearEditText);
        priceEditText = findViewById(R.id.priceEditText);
        registationEditText = findViewById(R.id.registationEditText);

        //LinearLayout ids
        imageUpload = findViewById(R.id.imageUpload);

        //ImageView ids
        imagePreview = findViewById(R.id.imagePreview);

        //Button ids
        btnSubmit = findViewById(R.id.btnSubmit);

        mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        //mLocationRequest.setSmallestDisplacement(5);  /* min dist for location change, here it is 10 meter */
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(LocationServices.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();

        mGoogleApiClient.connect();

        productTypeID = getIntent().getStringExtra("product_type_id");
        feCatID = getIntent().getStringExtra("fe_cat_id");


        if (productTypeID.equals("1"))
            hoursLayout.setVisibility(View.VISIBLE);
        else hoursLayout.setVisibility(View.GONE);



        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(brandNameStringValue)) {
                    Toast.makeText(AddProducts.this, "Please Select Brand", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(modelStringValue)) {
                    Toast.makeText(AddProducts.this, "Please Select Model", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(modelStringValue)) {
                    Toast.makeText(AddProducts.this, "Please Select Product", Toast.LENGTH_LONG).show();
                    return;
                }
                if (locationEditText.getText().toString().isEmpty()) {
                    text_input_location.setError("Please Enter Location");
                    return;
                }
                if (landmarkEditText.getText().toString().isEmpty()) {
                    text_input_landMark.setError("Please Enter Landmark");
                    return;
                }
               /* if (hoursEditText.getText().toString().isEmpty()) {
                    text_input_Hours.setError("Please Enter Hours");
                    return;
                }*/
                /*if (monthEditText.getText().toString().isEmpty()) {
                    text_input_Month.setError("Please Enter Month");
                    return;
                }*/

                if (yearEditText.getText().toString().isEmpty()) {
                    text_input_Year.setError("Please Enter Year");
                    return;
                }
                if (priceEditText.getText().toString().isEmpty()) {
                    text_input_Price.setError("Please Enter Price");
                    return;
                }
                if (registationEditText.getText().toString().isEmpty()) {
                    text_input_RegistrationNo.setError("Please Enter Registration No");
                    return;
                }

                addProductsData(locationEditText.getText().toString(), landmarkEditText.getText().toString(), hoursEditText.getText().toString(), yearEditText.getText().toString(),
                        priceEditText.getText().toString(), registationEditText.getText().toString());
            }
        });

        imageUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                photoOptions();
            }
        });

        brandsSpinnerData();


        // modelsSpinnerData();
        //productsSpinnerData();
        checkAndRequestPermissions();


    }

    private void brandsSpinnerData() {


        RequestParams params = new RequestParams();
        params.put("action", "getbrands");

      /*  JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject("product_image");
            jsonObject.put("value","");
            jsonObject.put("filetype","");
        } catch (JSONException e) {
            e.printStackTrace();
        }*/

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("Authorization", "Bearer " + PrefManager.getVendorToken(AddProducts.this, "token"));
        client.addHeader("Content-Type", "application/x-www-form-urlencoded");

        client.post(Urls.baseUrl, params, new AsyncHttpResponseHandler() {

            public void onStart() {

                progress = new ProgressDialog(AddProducts.this);
                progress.setTitle("Loading");
                progress.show();
// To dismiss the dialog


            }

            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final ArrayList<String> listCategory = new ArrayList<String>();
                final ArrayList<String> listCat_id = new ArrayList<String>();
                String s = new String(responseBody);
                try {

                    JSONObject jsonObject = new JSONObject(s);
                    JSONArray jsonArray = jsonObject.getJSONArray("response");

                    for (int i = 0; i < jsonArray.length(); i++) {

                        try {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);


                            String stateId = jsonObject1.getString("brand_id");
                            brandNameString = jsonObject1.getString("brand_name");
                            listCategory.add(brandNameString);
                            listCat_id.add(stateId);

                            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(),
                                    R.layout.spinner_item, listCategory);

                            brandSpinner.setAdapter(new NothingSelectedSpinnerAdapter(arrayAdapter, R.layout.brands_spinner_nothingselected, getApplicationContext()));

                            brandSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                    if (position == 0) {

                                        String s = listCat_id.get(position);
                                        brandNameStringValue = s;
                                        modelsSpinnerData(brandNameStringValue);

                                    } else {

                                        String s = listCat_id.get(position - 1);
                                        String title = listCategory.get(position - 1);
                                        brandNameStringValue = s;
                                        modelsSpinnerData(brandNameStringValue);

                                    }

                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });

                            progress.dismiss();

                        } catch (JSONException e1) {
                            progress.dismiss();
                            e1.printStackTrace();
                        }
                    }
                } catch (JSONException e) {
                    progress.dismiss();
                    e.printStackTrace();
                }
            }

            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable e) {
                progress.dismiss();
                Toast.makeText(AddProducts.this, "Please try again later..", Toast.LENGTH_LONG).show();
            }
        });

    }

    private void modelsSpinnerData(String brandId) {


        RequestParams params = new RequestParams();
        params.put("action", "getmodelsbybrandid");
        params.put("brand_id", brandId);

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE2MDc1MTMzMDYsImlzcyI6ImxvY2FsaG9zdCIsInVzZXJJZCI6IjMifQ.fJe_vwPPL9GhG-8decjnrZyqNEy2XeDIFzEGyccqPEA");
        client.addHeader("Content-Type", "application/x-www-form-urlencoded");

        client.post(Urls.baseUrl, params, new AsyncHttpResponseHandler() {

            public void onStart() {
                progress = new ProgressDialog(AddProducts.this);
                progress.setTitle("Loading");
                progress.show();

            }

            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final ArrayList<String> listCategory = new ArrayList<String>();
                final ArrayList<String> listCat_id = new ArrayList<String>();
                String s = new String(responseBody);
                try {

                    JSONObject jsonObject = new JSONObject(s);
                    JSONArray jsonArray = jsonObject.getJSONArray("response");

                    for (int i = 0; i < jsonArray.length(); i++) {

                        try {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);


                            String stateId = jsonObject1.getString("model_id");
                            modelString = jsonObject1.getString("models_name");
                            listCategory.add(modelString);
                            listCat_id.add(stateId);

                            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(),
                                    R.layout.spinner_item, listCategory);

                            modelSpinner.setAdapter(new NothingSelectedSpinnerAdapter(arrayAdapter, R.layout.models_spinner_nothingselected, getApplicationContext()));

                            modelSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                    if (position == 0) {

                                        String s = listCat_id.get(position);
                                        modelStringValue = s;

                                    } else {

                                        String s = listCat_id.get(position - 1);
                                        String title = listCategory.get(position - 1);
                                        modelStringValue = s;

                                    }

                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });

                            progress.dismiss();

                        } catch (JSONException e1) {
                            progress.dismiss();
                            e1.printStackTrace();
                        }
                    }
                } catch (JSONException e) {
                    progress.dismiss();
                    e.printStackTrace();
                }
            }

            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable e) {
                progress.dismiss();
                Toast.makeText(AddProducts.this, "Please try again later..", Toast.LENGTH_LONG).show();
            }
        });

    }

   /* private void productsSpinnerData() {


        RequestParams params = new RequestParams();
        params.put("action", "getproducttypes");

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE2MDc1MTMzMDYsImlzcyI6ImxvY2FsaG9zdCIsInVzZXJJZCI6IjMifQ.fJe_vwPPL9GhG-8decjnrZyqNEy2XeDIFzEGyccqPEA");
        client.addHeader("Content-Type", "application/x-www-form-urlencoded");

        client.post(Urls.baseUrl, params, new AsyncHttpResponseHandler() {

            public void onStart() {


            }

            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                final ArrayList<String> listCategory = new ArrayList<String>();
                final ArrayList<String> listCat_id = new ArrayList<String>();
                String s = new String(responseBody);
                try {

                    JSONObject jsonObject = new JSONObject(s);
                    JSONArray jsonArray = jsonObject.getJSONArray("response");

                    for (int i = 0; i < jsonArray.length(); i++) {

                        try {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);


                            String stateId = jsonObject1.getString("product_types_id");
                            productString = jsonObject1.getString("product_type_name");
                            listCategory.add(productString);
                            listCat_id.add(stateId);

                            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(),
                                    R.layout.spinner_item, listCategory);

                            productsSpinner.setAdapter(new NothingSelectedSpinnerAdapter(arrayAdapter, R.layout.products_spinner_nothingselected, getApplicationContext()));

                            productsSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                    if (position == 0) {

                                        String s = listCat_id.get(position);
                                        productStringValue = s;

                                    } else {

                                        String s = listCat_id.get(position - 1);
                                        String title = listCategory.get(position - 1);
                                        productStringValue = s;

                                    }

                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });


                        } catch (JSONException e1) {
                            e1.printStackTrace();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable e) {
                Toast.makeText(AddProducts.this, "Please try again later..", Toast.LENGTH_LONG).show();
            }
        });

    }*/

    //Photo upload starts----
    private void photoOptions() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose a option");
        // add a list
        String[] options = {"Camera", "Gallery"};
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0: // Camera
                        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(cameraIntent, CAMERA_REQUEST);
                        break;
                    case 1: // Gallery
                        Intent gallerypickerIntent = new Intent(Intent.ACTION_PICK);
                        gallerypickerIntent.setType("image/*");
                        startActivityForResult(gallerypickerIntent, PICTURE_TAKEN_FROM_GALLERY);
                        break;
                }
            }
        });
        // create and show the alert dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    Bitmap photo;

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST) {
            if (data != null) {
                if (data.getExtras() != null) {
                    photo = (Bitmap) data.getExtras().get("data");
                    img = getStringImage(photo);
                    imagePreview.setImageBitmap(photo);

                }
            }
        } else {
            if (requestCode == PICTURE_TAKEN_FROM_GALLERY && resultCode == RESULT_OK && null != data) {
                selectedImage = data.getData();

                getMimeType(selectedImage);

                ContentResolver cR = getApplicationContext().getContentResolver();
                MimeTypeMap mime = MimeTypeMap.getSingleton();
                imageType = mime.getExtensionFromMimeType(cR.getType(selectedImage));
                new AsyGalleryTask().execute();
                //ivImagePreviewFullScreen.setVisibility(View.VISIBLE);
                //ivImagePreviewFullScreen.setImageBitmap(BitmapFactory.decodeFile(picturePath));

            }
        }

    }

    class AsyGalleryTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
           /* pd=new ProgressDialog(AddRemittenceActivity.this);
            pd.setTitle("Please wait, image is being loaded.");
            pd.show();*/
        }

        @Override
        protected Void doInBackground(Void... params) {
            String[] filePathColumn = {MediaStore.Images.Media.DATA};

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();


            photo = BitmapFactory.decodeFile(picturePath);
            img = getStringImage(photo);
            return null;
        }

        @Override
        protected void onPostExecute(Void Void) {
            super.onPostExecute(Void);
            // pd.hide();
            imagePreview.setImageBitmap(photo);
            //  ivImagePreviewFullScreen.setImageBitmap(photo);
        }
    }

    public String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }


    public String getMimeType(Uri uri) {

        if (ContentResolver.SCHEME_CONTENT.equals(uri.getScheme())) {
            ContentResolver cr = getApplicationContext().getContentResolver();
            mimeType = cr.getType(uri);
        } else {
            String fileExtension = MimeTypeMap.getFileExtensionFromUrl(uri
                    .toString());
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                    fileExtension.toLowerCase());
        }
        return mimeType;
    }

    //Photo upload ends----


    private void addProductsData(String locationString, String landmarkString, String hoursString, String yearString, String priceString, String registationString) {

        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        params.put("action", "addproduct");
        params.put("fe_vendor_id", PrefManager.getfe_vendor_id(AddProducts.this, "fe_vendor_id"));
        params.put("fe_cat_id", feCatID);
        params.put("brand_id", brandNameStringValue);
        params.put("model_id", modelStringValue);
        params.put("product_types_id", productTypeID);
        params.put("product_condition", "NEW");
        params.put("location", locationString);
        params.put("latitude", lat);
        params.put("longitude", lang);
        params.put("land_mark", landmarkString);

        if (productTypeID.equals("1"))
        params.put("hours", hoursString);
        else  params.put("hours", "0");

        params.put("month", "0");
        params.put("year", yearString);
        params.put("price", priceString);
        params.put("registration_no", registationString);
       // params.put("value", img);
      //  params.put("filetype", "image/"+imageType);

        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject();
            jsonObject.put("filetype",mimeType);
            jsonObject.put("value", img);

        } catch (JSONException e) {
            e.printStackTrace();
        }
            params.put("product_image", jsonObject);

            Log.v("paramsvalue", params.toString());

            client.addHeader("Authorization", "Bearer " +PrefManager.getVendorToken(AddProducts.this, "token"));
            client.addHeader("Content-Type", "application/x-www-form-urlencoded");

            client.post(Urls.baseUrl,params,new AsyncHttpResponseHandler() {

                @Override
                public void onStart() {
                    // called before request is started

                    progressDialog = new ProgressDialog(AddProducts.this);
                    progressDialog.setMessage("Loading...");
                    progressDialog.setCancelable(false);
                    progressDialog.show();

                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] response) {
                    // called when response HTTP status is "200 OK"
                    try {

                        Log.v("response", response.toString());
                        JSONObject jsonObject = new JSONObject(new String(response));
                        if (jsonObject.getString("statusCode").equalsIgnoreCase("1")) {
                            Toast.makeText(AddProducts.this, "Form submitted sucessfully", Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                            finish();
                        } else {
                            Toast.makeText(AddProducts.this, "Please Try Again later", Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        progressDialog.dismiss();

                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e) {

                    Log.v("error", errorResponse.toString());
                    Toast.makeText(AddProducts.this, errorResponse.toString(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();


                }
            });
        }

    private  boolean checkAndRequestPermissions() {
        int permissionSendMessage = ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS);
        int locationPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (locationPermission != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (permissionSendMessage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]),REQUEST_ID_MULTIPLE_PERMISSIONS);
            return false;
        }
        return true;
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Location mCurrentLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (mCurrentLocation != null) {
            // Print current location if not null
            //Log.d("DEBUG", "current location: " + mCurrentLocation.toString());
            lat = Double.toString(mCurrentLocation.getLatitude());
            lang = Double.toString(mCurrentLocation.getLongitude());

            msg = "Current Location: " +
                    Double.toString(mCurrentLocation.getLatitude()) + "," +
                    Double.toString(mCurrentLocation.getLongitude());
            // Toast.makeText(this, lat+lang, Toast.LENGTH_SHORT).show();

            //    latLog.setText("Current Location: " +lat+", "+lang);


            Geocoder geocoder;
            List<Address> addresses;
            geocoder = new Geocoder(this, Locale.getDefault());

            try {
                addresses = geocoder.getFromLocation(mCurrentLocation.getLatitude(),mCurrentLocation.getLongitude(), 1);// Here 1 represent max location result to returned, by documents it recommended 1 to 5

                address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                String city = addresses.get(0).getLocality();
                String state = addresses.get(0).getAdminArea();
                String country = addresses.get(0).getCountryName();
                String postalCode = addresses.get(0).getPostalCode();
                String knownName = addresses.get(0).getFeatureName();

                //  addressText.setText("Current Location: " +address+", "+city);
            } catch (IOException e) {
                e.printStackTrace();
            }


        }

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }


    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setTitle("Location Permission Needed")
                        .setMessage("This app needs the Location permission, please accept to use location functionality")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(AddProducts.this,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {


                    }

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(this, "permission denied", Toast.LENGTH_LONG).show();
                }
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

}



