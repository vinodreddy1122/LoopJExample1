package com.vsmart.farmengineer.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.adapters.TypesAdapter;
import com.vsmart.farmengineer.models.TypesHelper;
import com.vsmart.farmengineer.utils.PrefManager;
import com.vsmart.farmengineer.utils.Urls;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import pl.droidsonroids.gif.GifImageView;

public class CategoryActivity extends AppCompatActivity {

    RecyclerView types_recycler;
    List<TypesHelper> categoriesHelpers;
    private TypesAdapter recyclerviewViewadapter;
    GifImageView progressBar;
    TextView nodataFound;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        types_recycler = findViewById(R.id.types_recycler);
        progressBar = findViewById(R.id.progressBar);
        nodataFound = findViewById(R.id.nodataFound);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(CategoryActivity.this, RecyclerView.VERTICAL, false);
        types_recycler.setLayoutManager(layoutManager);
        types_recycler.setHasFixedSize(true);
        types_recycler.setNestedScrollingEnabled(false);

        init();
    }

    private void init(){


        RequestParams params = new RequestParams();
        params.put("action", "getproducttypes");

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("Authorization","Bearer "+PrefManager.getVendorToken(CategoryActivity.this, "token"));
        client.addHeader("Content-Type","application/x-www-form-urlencoded");

        client.post(Urls.baseUrl,params,new AsyncHttpResponseHandler() {


            public void onStart() {
                progressBar.setVisibility(View.VISIBLE);
                nodataFound.setVisibility(View.GONE);
                types_recycler.setVisibility(View.GONE);

            }

            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                String s = new String(responseBody);
                try {

                    JSONObject jsonObject = new JSONObject(s);
                    JSONArray responseArray = jsonObject.getJSONArray("response");
                    if (jsonObject.getString("statusCode").equals("1")) {
                        categoriesHelpers = new ArrayList<TypesHelper>();
                        TypesHelper categoriesHelper;

                        for (int i = 0; i < responseArray.length(); i++) {
                            JSONObject jsonObject1 = responseArray.getJSONObject(i);

                            categoriesHelper = new TypesHelper();
                            categoriesHelper.setProduct_types_id(jsonObject1.getString("product_types_id"));
                            categoriesHelper.setProduct_type_name(jsonObject1.getString("product_type_name"));
                            categoriesHelper.setColor_code(jsonObject1.getString("color_code"));


                            categoriesHelpers.add(categoriesHelper);

                        }

                        recyclerviewViewadapter = new TypesAdapter(categoriesHelpers, CategoryActivity.this);
                        types_recycler.setAdapter(recyclerviewViewadapter);
                        progressBar.setVisibility(View.GONE);
                        nodataFound.setVisibility(View.GONE);
                        types_recycler.setVisibility(View.VISIBLE);

                    }else {
                        progressBar.setVisibility(View.GONE);
                        nodataFound.setVisibility(View.VISIBLE);
                        types_recycler.setVisibility(View.GONE);
                    }

                }catch(JSONException e){
                    progressBar.setVisibility(View.GONE);
                    types_recycler.setVisibility(View.GONE);
                    Toast.makeText(CategoryActivity.this, "Loading failed...", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }


            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable e) {
                progressBar.setVisibility(View.GONE);
                types_recycler.setVisibility(View.GONE);
                Toast.makeText(CategoryActivity.this,"Loading failed...",Toast.LENGTH_LONG).show();
            }
        });

    }
}
