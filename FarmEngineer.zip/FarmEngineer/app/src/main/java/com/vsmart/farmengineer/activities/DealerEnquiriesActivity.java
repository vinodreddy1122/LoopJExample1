package com.vsmart.farmengineer.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.adapters.DealerEnquiriesAdapter;
import com.vsmart.farmengineer.adapters.TypesAdapter;
import com.vsmart.farmengineer.adapters.UserEnquiriesAdapter;
import com.vsmart.farmengineer.models.GetProductsByIdHelper;
import com.vsmart.farmengineer.models.TypesHelper;
import com.vsmart.farmengineer.utils.PrefManager;
import com.vsmart.farmengineer.utils.Urls;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import pl.droidsonroids.gif.GifImageView;

public class DealerEnquiriesActivity extends AppCompatActivity {

    RecyclerView types_recycler;
    List<GetProductsByIdHelper> GetProductsByIdHelpers;
    private DealerEnquiriesAdapter recyclerviewViewadapter;
    GifImageView progressBar;
    TextView nodataFound;
    Toolbar toolbar;
    String productsTypeId,CatID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dealer_enquiries);


        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_white_24);


        types_recycler = findViewById(R.id.types_recycler);
        progressBar = findViewById(R.id.progressBar);
        nodataFound = findViewById(R.id.nodataFound);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(DealerEnquiriesActivity.this, RecyclerView.VERTICAL, false);
        types_recycler.setLayoutManager(layoutManager);
        types_recycler.setHasFixedSize(true);
        types_recycler.setNestedScrollingEnabled(false);





        init();
    }

    private void init(){


        RequestParams params = new RequestParams();
        params.put("action", "getenquiriesbyvendorid");
        params.put("fe_vendor_id", PrefManager.getfe_vendor_id(DealerEnquiriesActivity.this, "fe_vendor_id"));

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("Authorization","Bearer "+PrefManager.getVendorToken(DealerEnquiriesActivity.this, "token"));
        client.addHeader("Content-Type","application/x-www-form-urlencoded");

        Log.v("paramsvalue", params.toString());

        client.post(Urls.baseUrl,params,new AsyncHttpResponseHandler() {


            public void onStart() {
                progressBar.setVisibility(View.VISIBLE);
                nodataFound.setVisibility(View.GONE);
                types_recycler.setVisibility(View.GONE);

            }

            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                String s = new String(responseBody);
                try {

                    JSONObject jsonObject = new JSONObject(s);

                    JSONArray responseArray = jsonObject.getJSONArray("response");

                    if (responseArray.length()>0) {
                        if (jsonObject.getString("statusCode").equals("1")) {
                            GetProductsByIdHelpers = new ArrayList<GetProductsByIdHelper>();
                            GetProductsByIdHelper GetProductsByIdHelper;

                            for (int i = 0; i < responseArray.length(); i++) {
                                JSONObject jsonObject1 = responseArray.getJSONObject(i);

                                GetProductsByIdHelper = new GetProductsByIdHelper();
                                GetProductsByIdHelper.setFe_product_id(jsonObject1.getString("fe_product_id"));
                                GetProductsByIdHelper.setFe_vendor_id(jsonObject1.getString("fe_vendor_id"));
                                GetProductsByIdHelper.setBrand_name(jsonObject1.getString("brand_name"));
                                GetProductsByIdHelper.setModels_name(jsonObject1.getString("models_name"));
                                GetProductsByIdHelper.setProduct_condition(jsonObject1.getString("product_condition"));
                                GetProductsByIdHelper.setYear(jsonObject1.getString("year"));
                                GetProductsByIdHelper.setPrice(jsonObject1.getString("price"));
                                GetProductsByIdHelper.setFe_name(jsonObject1.getString("fe_name"));
                                GetProductsByIdHelper.setFe_mobile(jsonObject1.getString("fe_mobile"));
                                GetProductsByIdHelper.setFe_email(jsonObject1.getString("fe_email"));
                                GetProductsByIdHelper.setProduct_img(jsonObject1.getString("product_img"));


                                GetProductsByIdHelpers.add(GetProductsByIdHelper);

                            }

                            recyclerviewViewadapter = new DealerEnquiriesAdapter(GetProductsByIdHelpers, DealerEnquiriesActivity.this);
                            types_recycler.setAdapter(recyclerviewViewadapter);
                            progressBar.setVisibility(View.GONE);
                            nodataFound.setVisibility(View.GONE);
                            types_recycler.setVisibility(View.VISIBLE);

                        } else {
                            progressBar.setVisibility(View.GONE);
                            nodataFound.setVisibility(View.VISIBLE);
                            types_recycler.setVisibility(View.GONE);
                        }
                    }else {
                        progressBar.setVisibility(View.GONE);
                        nodataFound.setVisibility(View.VISIBLE);
                        types_recycler.setVisibility(View.GONE);
                    }

                }catch(JSONException e){
                    progressBar.setVisibility(View.GONE);
                    types_recycler.setVisibility(View.GONE);
                    Toast.makeText(DealerEnquiriesActivity.this, "Loading failed...", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }


            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable e) {
                progressBar.setVisibility(View.GONE);
                types_recycler.setVisibility(View.GONE);
                Toast.makeText(DealerEnquiriesActivity.this,"Loading failed...",Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public void onBackPressed() {
        init();
        super.onBackPressed();
    }
}