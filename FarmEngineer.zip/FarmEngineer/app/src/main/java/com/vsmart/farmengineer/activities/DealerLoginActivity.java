package com.vsmart.farmengineer.activities;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


import org.json.JSONException;
import org.json.JSONObject;

import java.security.KeyStore;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.MySSLSocketFactory;
import com.loopj.android.http.RequestParams;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.useractivites.FarmerLoginActivity;
import com.vsmart.farmengineer.useractivites.FarmerRegistationActivity;
import com.vsmart.farmengineer.utils.CheckNetwork;
import com.vsmart.farmengineer.utils.PrefManager;
import com.vsmart.farmengineer.utils.Urls;

import cz.msebera.android.httpclient.Header;



public class DealerLoginActivity extends AppCompatActivity implements View.OnFocusChangeListener {

    AppCompatButton signin_cv;
    EditText userid_et,password_et;
    ProgressDialog progressDialog;
    TextView signup_tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dealer_login);

     //   getSupportActionBar().hide();
        checkLocationPermission();

        signin_cv = findViewById(R.id.signin_cv);

        signup_tv = findViewById(R.id.signup_tv);

        userid_et = findViewById(R.id.userid_et);
        password_et = findViewById(R.id.password_et);

        userid_et.setOnFocusChangeListener(this);
        password_et.setOnFocusChangeListener(this);


        //    empId.setText(PrefManager.getEmpCode(DealerLoginActivity.this, "username"));
        //    password.setText(PrefManager.getPassword(DealerLoginActivity.this, "password"));

        signup_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DealerLoginActivity.this, DealerRegistationActivity.class);
                startActivity(intent);
            }
        });

        signin_cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (userid_et.getText().toString().isEmpty()){
                    userid_et.setError("Please Enter Employee Id");
                    return;
                }

                if (password_et.getText().toString().isEmpty()){
                    password_et.setError("Please Enter Password");
                    return;
                }

                loginData(userid_et.getText().toString(),password_et.getText().toString());
            }
        });

    }

    private void loginData(String mobileString,String passwordString) {

        RequestParams params = new RequestParams();
        params.put("action", "userlogin");
        params.put("mobile_no", mobileString);
        params.put("password", passwordString);

       /* AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("action","userlogin");*/

        if (CheckNetwork.isInternetAvailable(DealerLoginActivity.this)) {
            AsyncHttpClient client = new AsyncHttpClient();
            try {
                KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
                trustStore.load(null, null);
                MySSLSocketFactory sf = new MySSLSocketFactory(trustStore);
                sf.setHostnameVerifier(MySSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
                client.setSSLSocketFactory(sf);
            } catch (Exception e) {
            }
            client.post(Urls.baseUrl,params, new AsyncHttpResponseHandler() {


                @Override
                public void onStart() {
                    // called before request is started
                    progressDialog = new ProgressDialog(DealerLoginActivity.this);
                    progressDialog.setMessage("SignIn...");
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] response) {
                    // called when response HTTP status is "200 OK"
                    try {
                        JSONObject jsonObject = new JSONObject(new String(response));


                        if (jsonObject.getString("statusCode").equalsIgnoreCase("1")){
                            PrefManager.setVendorToken(DealerLoginActivity.this, "token", jsonObject.getString("token"));

                            JSONObject responseObject = jsonObject.getJSONObject("response");

                            Log.v("status", responseObject.toString());
                            if (jsonObject.getString("statusCode").equalsIgnoreCase("1")) {

                                PrefManager.setfe_vendor_id(DealerLoginActivity.this, "fe_vendor_id", responseObject.getString("fe_vendor_id"));
                                PrefManager.setfull_name(DealerLoginActivity.this, "full_name", responseObject.getString("full_name"));
                                PrefManager.setemail_id(DealerLoginActivity.this, "email_id", responseObject.getString("email_id"));
                                PrefManager.setmobile_no(DealerLoginActivity.this, "mobile_no", responseObject.getString("mobile_no"));
                                PrefManager.setuser_type(DealerLoginActivity.this, "user_type", responseObject.getString("user_type"));
                                Intent intent = new Intent(DealerLoginActivity.this, CategoryActivity.class);
                                startActivity(intent);
                                finish();
                                progressDialog.dismiss();
                            }
                            // progressDialog.dismiss();
                        } else {
                            Toast.makeText(DealerLoginActivity.this, jsonObject.getString("msg"), Toast.LENGTH_LONG).show();
                           /* Snackbar snackbar1 = Snackbar.make(coordinatorLayout, "Invalid Username/Password", Snackbar.LENGTH_SHORT);
                            snackbar1.show();*/
                            //progressDialog.dismiss();
                            progressDialog.dismiss();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        //progressDialog.dismiss();
                        progressDialog.dismiss();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e) {
                    // progressDialog.dismiss();
                    Toast.makeText(DealerLoginActivity.this,"Try Again later",Toast.LENGTH_SHORT).show();
                   /* Snackbar snackbar1 = Snackbar.make(coordinatorLayout, "Try Again later", Snackbar.LENGTH_SHORT);
                    snackbar1.show();*/
                    progressDialog.dismiss();
                }
            });

        } else{
            Toast.makeText(DealerLoginActivity.this, getString(R.string.noInternetText), Toast.LENGTH_SHORT).show();
            /*Snackbar snackbar1 = Snackbar.make(coordinatorLayout, R.string.noInternetText, Snackbar.LENGTH_SHORT);
            snackbar1.show();*/
        }
    }

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setTitle("Location Permission Needed")
                        .setMessage("This app needs the Location permission, please accept to use location functionality")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(DealerLoginActivity.this,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {


                    }

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(this, "permission denied", Toast.LENGTH_LONG).show();
                }
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }


    public void hideKeyboard(View view) {
        InputMethodManager inputMethodManager =(InputMethodManager)getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    @Override
    public void onFocusChange(View view, boolean hasFocus) {
        if (!hasFocus) {
            hideKeyboard(view);
        }
    }
}