package com.vsmart.farmengineer.activities;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.utils.PrefManager;

public class DealerProfileActivity extends AppCompatActivity {

    TextView userName,useremailId,usermobileNumber;
    RelativeLayout logoutFooter;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dealer_profile);


        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_white_24);

        userName = findViewById(R.id.userName);
        useremailId = findViewById(R.id.useremailId);
        usermobileNumber = findViewById(R.id.usermobileNumber);
        logoutFooter = findViewById(R.id.logoutFooter);

        userName.setText(PrefManager.getfull_name(DealerProfileActivity.this, "full_name"));
        useremailId.setText(PrefManager.getemail_id(DealerProfileActivity.this, "email_id"));
        usermobileNumber.setText(PrefManager.getmobile_no(DealerProfileActivity.this, "mobile_no"));

        logoutFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(DealerProfileActivity.this, R.style.AppCompatAlertDialogStyle);
                builder.setTitle("Are you sure want to logout?");
                builder.setIcon(R.drawable.logout_icon_png);

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        PrefManager.setfe_vendor_id(DealerProfileActivity.this,"fe_vendor_id","");

                        Intent intent = new Intent(DealerProfileActivity.this, SelectionActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }

                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });


    }
}
