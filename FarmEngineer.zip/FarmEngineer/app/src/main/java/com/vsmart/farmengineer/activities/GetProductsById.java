package com.vsmart.farmengineer.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.adapters.GetProductsByIdAdapter;
import com.vsmart.farmengineer.adapters.TypesAdapter;
import com.vsmart.farmengineer.models.GetProductsByIdHelper;
import com.vsmart.farmengineer.models.TypesHelper;
import com.vsmart.farmengineer.utils.PrefManager;
import com.vsmart.farmengineer.utils.Urls;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import pl.droidsonroids.gif.GifImageView;

public class GetProductsById extends AppCompatActivity {

    RecyclerView types_recycler;
    List<GetProductsByIdHelper> getProductsByIdHelpers;
    private GetProductsByIdAdapter recyclerviewViewadapter;
    GifImageView progressBar;
    TextView nodataFound;
    FloatingActionButton fab;
    Toolbar toolbar;
    String productsTypeId,CatID;
    TextView toolbarText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_products_by_id);


        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbarText = findViewById(R.id.toolbarText);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_white_24);

        toolbarText.setText(getIntent().getStringExtra("fe_cat_name"));


        types_recycler = findViewById(R.id.types_recycler);
        progressBar = findViewById(R.id.progressBar);
        nodataFound = findViewById(R.id.nodataFound);
        fab = findViewById(R.id.fab);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(GetProductsById.this, RecyclerView.VERTICAL, false);
        types_recycler.setLayoutManager(layoutManager);
        types_recycler.setHasFixedSize(true);
        types_recycler.setNestedScrollingEnabled(false);


        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(GetProductsById.this,AddProducts.class);
                intent.putExtra("product_type_id",getIntent().getStringExtra("product_types_id"));
                intent.putExtra("fe_cat_id",getIntent().getStringExtra("fe_cat_id"));
                startActivity(intent);
            }
        });



        init(getIntent().getStringExtra("fe_cat_id"),getIntent().getStringExtra("product_types_id"));
    }

    private void init(final String feCatId, final String productsTypesID){


        RequestParams params = new RequestParams();
        params.put("action", "getproductsbyvendorid");
        params.put("fe_vendor_id", PrefManager.getfe_vendor_id(GetProductsById.this, "fe_vendor_id"));
        params.put("fe_cat_id", feCatId);
        params.put("product_types_id", productsTypesID);

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("Authorization","Bearer "+PrefManager.getVendorToken(GetProductsById.this, "token"));
        client.addHeader("Content-Type","application/x-www-form-urlencoded");

        Log.v("paramsvalue", params.toString());

        client.post(Urls.baseUrl,params,new AsyncHttpResponseHandler() {


            public void onStart() {
                progressBar.setVisibility(View.VISIBLE);
                nodataFound.setVisibility(View.GONE);
                types_recycler.setVisibility(View.GONE);

            }

            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                String s = new String(responseBody);
                try {

                    JSONObject jsonObject = new JSONObject(s);

                    JSONArray responseArray = jsonObject.getJSONArray("response");

                    if (responseArray.length()>0) {
                        if (jsonObject.getString("statusCode").equals("1")) {
                            getProductsByIdHelpers = new ArrayList<GetProductsByIdHelper>();
                            GetProductsByIdHelper getProductsByIdHelper;

                            for (int i = 0; i < responseArray.length(); i++) {
                                JSONObject jsonObject1 = responseArray.getJSONObject(i);

                                getProductsByIdHelper = new GetProductsByIdHelper();
                                getProductsByIdHelper.setCat_name(jsonObject1.getString("cat_name"));
                                getProductsByIdHelper.setBrand_name(jsonObject1.getString("brand_name"));
                                getProductsByIdHelper.setModels_name(jsonObject1.getString("models_name"));
                                getProductsByIdHelper.setProduct_types_id(jsonObject1.getString("product_types_id"));
                                getProductsByIdHelper.setProduct_condition(jsonObject1.getString("product_condition"));
                                getProductsByIdHelper.setLocation(jsonObject1.getString("location"));
                                getProductsByIdHelper.setLand_mark(jsonObject1.getString("land_mark"));
                                getProductsByIdHelper.setHours(jsonObject1.getString("hours"));
                                getProductsByIdHelper.setMonth(jsonObject1.getString("month"));
                                getProductsByIdHelper.setYear(jsonObject1.getString("year"));
                                getProductsByIdHelper.setPrice(jsonObject1.getString("price"));
                                getProductsByIdHelper.setRegistration_no(jsonObject1.getString("registration_no"));
                                getProductsByIdHelper.setProduct_img(jsonObject1.getString("product_img"));
                                getProductsByIdHelper.setFe_product_id(jsonObject1.getString("fe_product_id"));


                                getProductsByIdHelpers.add(getProductsByIdHelper);

                            }

                            recyclerviewViewadapter = new GetProductsByIdAdapter(getProductsByIdHelpers, GetProductsById.this, feCatId, productsTypesID);
                            types_recycler.setAdapter(recyclerviewViewadapter);
                            progressBar.setVisibility(View.GONE);
                            nodataFound.setVisibility(View.GONE);
                            types_recycler.setVisibility(View.VISIBLE);

                        } else {
                            progressBar.setVisibility(View.GONE);
                            nodataFound.setVisibility(View.VISIBLE);
                            types_recycler.setVisibility(View.GONE);
                        }
                    }else {
                        progressBar.setVisibility(View.GONE);
                        nodataFound.setVisibility(View.VISIBLE);
                        types_recycler.setVisibility(View.GONE);
                    }

                }catch(JSONException e){
                    progressBar.setVisibility(View.GONE);
                    types_recycler.setVisibility(View.GONE);
                    Toast.makeText(GetProductsById.this, "Loading failed...", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }


            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable e) {
                progressBar.setVisibility(View.GONE);
                types_recycler.setVisibility(View.GONE);
                Toast.makeText(GetProductsById.this,"Loading failed...",Toast.LENGTH_LONG).show();
            }
        });

    }
    @Override
    protected void onRestart() {
        init(getIntent().getStringExtra("fe_cat_id"),getIntent().getStringExtra("product_types_id"));
        super.onRestart();
    }
}
