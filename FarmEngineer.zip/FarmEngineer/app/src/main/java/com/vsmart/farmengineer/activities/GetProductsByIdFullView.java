package com.vsmart.farmengineer.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.utils.PrefManager;
import com.vsmart.farmengineer.utils.Urls;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;
import pl.droidsonroids.gif.GifImageView;

public class GetProductsByIdFullView extends AppCompatActivity {

    ImageView categoryImage;
    TextView brand_name,models_name,location,landMark,hours,year,price,registration_no;
 //   FloatingActionButton fab_edit;
    String productsTypesID,feCatId;
    FloatingActionButton fab_edit;
    Toolbar toolbar;
    CardView card_view;
    TextView nodataFound;
    GifImageView progressBar;
    String brandName,modelName,locationString,landMarkString,hoursString,monthString,yearString,priceString,RegistrationNoString,fe_product_idString;
    String brandId,modelId,productImg;
    TextView toolbarText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_products_by_id_full_view);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_white_24);

        toolbarText = findViewById(R.id.toolbarText);

        toolbarText.setText(getIntent().getStringExtra("brand_name"));

        categoryImage = findViewById(R.id.categoryImage);
        brand_name = findViewById(R.id.brand_name);
        models_name = findViewById(R.id.models_name);
        location = findViewById(R.id.location);
        landMark = findViewById(R.id.landMark);
        hours = findViewById(R.id.hours);
       // month = findViewById(R.id.month);
        year = findViewById(R.id.year);
        price = findViewById(R.id.price);
        registration_no = findViewById(R.id.registration_no);

        fab_edit = findViewById(R.id.fab_edit);
        nodataFound = findViewById(R.id.nodataFound);
        progressBar = findViewById(R.id.progressBar);

        card_view = findViewById(R.id.card_view);


        fe_product_idString = getIntent().getStringExtra("fe_product_id");


         productsTypesID = getIntent().getStringExtra("productsTypesID");
         feCatId = getIntent().getStringExtra("feCatId");

        fab_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(GetProductsByIdFullView.this,GetProductsEditActivity.class);
                intent.putExtra("fe_product_id",fe_product_idString);
                intent.putExtra("productImg",productImg);
                startActivity(intent);

            }
        });

        init(fe_product_idString);
    }

    private void init(String fe_product_idString){


        RequestParams params = new RequestParams();
        params.put("action", "getproductdetailsbyid");
        params.put("fe_product_id",fe_product_idString);

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("Authorization","Bearer "+PrefManager.getVendorToken(GetProductsByIdFullView.this, "token"));
        client.addHeader("Content-Type","application/x-www-form-urlencoded");

        Log.v("paramsvalue", params.toString());

        client.post(Urls.baseUrl,params,new AsyncHttpResponseHandler() {


            public void onStart() {
                progressBar.setVisibility(View.VISIBLE);
                nodataFound.setVisibility(View.GONE);
                card_view.setVisibility(View.GONE);

            }

            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                String s = new String(responseBody);
                try {

                    JSONObject jsonObject = new JSONObject(s);

                    JSONObject responseArray = jsonObject.getJSONObject("response");

                    if (responseArray.length()>0) {
                        if (jsonObject.getString("statusCode").equals("1")) {


                                brandName = responseArray.getString("brand_name");
                                modelName = responseArray.getString("models_name");
                                locationString = responseArray.getString("location");
                                landMarkString = responseArray.getString("land_mark");
                                hoursString = responseArray.getString("hours");
                                monthString = responseArray.getString("month");
                                yearString = responseArray.getString("year");
                                priceString = responseArray.getString("price");
                                RegistrationNoString = responseArray.getString("registration_no");

                                 brandId =responseArray.getString("brand_id");
                                modelId =responseArray.getString("model_id");
                                productImg = responseArray.getString("product_img");



                                    brand_name.setText("Brand Name: "+brandName);
                                models_name.setText("Model Name: "+modelName);
                                location.setText("Location: "+locationString);
                                landMark.setText("Landmark: "+landMarkString);
                                hours.setText("Hours: "+hoursString);
                              //  month.setText("Month: "+monthString);
                                year.setText("Year of Modal (Eg: 2020): "+yearString);
                                price.setText("Price: "+priceString);
                                registration_no.setText("Registration Number: "+RegistrationNoString);




                            Glide.with(GetProductsByIdFullView.this)
                                    .load("https://farm.smartmindsteam.com"+responseArray.getString("product_img"))
                                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                                    .placeholder(R.drawable.placeholder)
                                    .into(categoryImage);

                                progressBar.setVisibility(View.GONE);
                                nodataFound.setVisibility(View.GONE);
                                card_view.setVisibility(View.VISIBLE);



                        } else {
                            progressBar.setVisibility(View.GONE);
                            nodataFound.setVisibility(View.VISIBLE);
                            card_view.setVisibility(View.GONE);
                        }
                    }else {
                        progressBar.setVisibility(View.GONE);
                        nodataFound.setVisibility(View.VISIBLE);
                        card_view.setVisibility(View.GONE);
                    }

                }catch(JSONException e){
                    progressBar.setVisibility(View.GONE);
                    card_view.setVisibility(View.GONE);
                    Toast.makeText(GetProductsByIdFullView.this, "Loading failed...", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }


            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable e) {
                progressBar.setVisibility(View.GONE);
                card_view.setVisibility(View.GONE);
                Toast.makeText(GetProductsByIdFullView.this,"Loading failed...",Toast.LENGTH_LONG).show();
            }
        });

    }
}
