package com.vsmart.farmengineer.activities;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.adapters.CategoriesAdapter;
import com.vsmart.farmengineer.adapters.TypesAdapter;
import com.vsmart.farmengineer.models.CategoriesHelper;
import com.vsmart.farmengineer.models.TypesHelper;
import com.vsmart.farmengineer.utils.PrefManager;
import com.vsmart.farmengineer.utils.Urls;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import pl.droidsonroids.gif.GifImageView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    public DrawerLayout drawer;
    Toolbar toolbar;
    public NavigationView navigationView;
    RecyclerView categoriesRecycler;
    GifImageView progressBar;
    TextView nodataFound;
    List<CategoriesHelper> categoriesHelpers;
    private CategoriesAdapter recyclerviewViewadapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        getSupportActionBar().hide();

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(getResources().getString(R.string.app_name));

        categoriesRecycler = findViewById(R.id.categoriesRecycler);
        progressBar = findViewById(R.id.progressBar);
        nodataFound = findViewById(R.id.nodataFound);

       // RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(MainActivity.this, RecyclerView.VERTICAL, false);
       // categoriesRecycler.setLayoutManager(layoutManager);
        categoriesRecycler.setLayoutManager(new GridLayoutManager(this, 2));

        categoriesRecycler.setHasFixedSize(true);
        categoriesRecycler.setNestedScrollingEnabled(false);

        init(getIntent().getStringExtra("cat_id"));


        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        toolbar.setNavigationIcon(R.drawable.ic_menu_black_24dp);

        navigationView = findViewById(R.id.nav_view);
        navigationView.setItemIconTintList(null);
        navigationView.setNavigationItemSelectedListener(this);

        View header = navigationView.getHeaderView(0);
        TextView userName = (TextView) header.findViewById(R.id.userName);
        userName.setText(PrefManager.getfull_name(MainActivity.this, "full_name"));

        LinearLayout headerLayout = header.findViewById(R.id.headerLayout);

        TextView userEmail = (TextView) header.findViewById(R.id.userEmail);
        userEmail.setText(PrefManager.getemail_id(MainActivity.this, "email_id"));

        headerLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,DealerProfileActivity.class);
                startActivity(intent);
            }
        });



    //    navigationView.getMenu().getItem(0).setChecked(true);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        //Checking if the item is in checked state or not, if not make it in checked state
        if (item.isChecked())
            item.setChecked(false);
        else
            item.setChecked(true);

        //Closing drawer on item click
        drawer.closeDrawers();

        // Handle navigation view item clicks here.
        int id = item.getItemId();

        switch (id) {

            case R.id.home:
                Intent intent1 = new Intent(MainActivity.this, CategoryActivity.class);
                intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent1);
                return true;

            case R.id.enquiries:
                Intent intent = new Intent(MainActivity.this, DealerEnquiriesActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                return true;

                case R.id.logout:

                    final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this, R.style.AppCompatAlertDialogStyle);
                    builder.setTitle("Are you sure want to logout?");
                    builder.setIcon(R.drawable.logout_icon_png);

                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {

                            PrefManager.setfe_vendor_id(MainActivity.this,"fe_vendor_id","");

                            Intent intent = new Intent(MainActivity.this, SelectionActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                            finish();
                        }
                    });

                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }

                    });
                    AlertDialog dialog = builder.create();
                    dialog.show();

                return true;

         /*   case R.id.rateUs:
                Intent viewIntent = new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=com.app.animalvideos"));
                startActivity(viewIntent);
                return true;

            case R.id.share:
                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_SUBJECT, "Animal Videos");
                    String sAux = "\nJallikattu Videos, Wild Animals, Funny Animals, Water Animals, etc. ...\n\n";
                    sAux = sAux + "https://play.google.com/store/apps/details?id=com.app.animalvideos \n\n";
                    i.putExtra(Intent.EXTRA_TEXT, sAux);
                    startActivity(Intent.createChooser(i, "choose one"));
                } catch(Exception e) {
                    //e.toString();
                }
                return true;

            case R.id.contact:
                Intent viewIntent1 = new Intent(HomeActivity.this,ContactUsActivity.class);
                startActivity(viewIntent1);
                return true;

            case R.id.moreApps:
                Intent viewIntent2 = new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/developer?id=RCR+GROUP"));
                startActivity(viewIntent2);
                return true;*/



            default:
                return true;
        }
    }

    private void init(final String cat_id){


        RequestParams params = new RequestParams();
        params.put("action", "getcategory");
        //params.put("cat_type_id", cat_id);

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("Authorization","Bearer "+PrefManager.getVendorToken(MainActivity.this, "token"));
        client.addHeader("Content-Type","application/x-www-form-urlencoded");

        client.post(Urls.baseUrl,params,new AsyncHttpResponseHandler() {


            public void onStart() {
                progressBar.setVisibility(View.VISIBLE);
                nodataFound.setVisibility(View.GONE);
                categoriesRecycler.setVisibility(View.GONE);

            }

            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                String s = new String(responseBody);
                try {

                    JSONObject jsonObject = new JSONObject(s);
                    JSONArray responseArray = jsonObject.getJSONArray("response");
                    if (jsonObject.getString("statusCode").equals("1")) {
                        categoriesHelpers = new ArrayList<CategoriesHelper>();
                        CategoriesHelper categoriesHelper;

                        for (int i = 0; i < responseArray.length(); i++) {
                            JSONObject jsonObject1 = responseArray.getJSONObject(i);

                            categoriesHelper = new CategoriesHelper();
                            categoriesHelper.setFe_cat_id(jsonObject1.getString("fe_cat_id"));
                            categoriesHelper.setCat_name(jsonObject1.getString("cat_name"));
                            categoriesHelper.setCat_img(jsonObject1.getString("cat_img"));


                            categoriesHelpers.add(categoriesHelper);

                        }

                        recyclerviewViewadapter = new CategoriesAdapter(categoriesHelpers, MainActivity.this,cat_id);
                        categoriesRecycler.setAdapter(recyclerviewViewadapter);
                        progressBar.setVisibility(View.GONE);
                        nodataFound.setVisibility(View.GONE);
                        categoriesRecycler.setVisibility(View.VISIBLE);

                    }else {
                        progressBar.setVisibility(View.GONE);
                        nodataFound.setVisibility(View.VISIBLE);
                        categoriesRecycler.setVisibility(View.GONE);
                    }

                }catch(JSONException e){
                    progressBar.setVisibility(View.GONE);
                    categoriesRecycler.setVisibility(View.GONE);
                    Toast.makeText(MainActivity.this, "Loading failed...", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }


            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable e) {
                progressBar.setVisibility(View.GONE);
                categoriesRecycler.setVisibility(View.GONE);
                Toast.makeText(MainActivity.this,"Loading failed...",Toast.LENGTH_LONG).show();
            }
        });

    }
}
