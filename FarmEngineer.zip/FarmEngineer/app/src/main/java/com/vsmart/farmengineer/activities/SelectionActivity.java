package com.vsmart.farmengineer.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.useractivites.FarmerLoginActivity;

import java.util.ArrayList;
import java.util.List;

public class SelectionActivity extends AppCompatActivity implements View.OnClickListener {

    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);
       // getSupportActionBar().hide();
        CardView farmer_cv = findViewById(R.id.farmer_cv);
        CardView dealer_cv = findViewById(R.id.dealer_cv);
        farmer_cv.setOnClickListener(this);
        dealer_cv.setOnClickListener(this);

        checkAndRequestPermissions();
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.farmer_cv:
                Intent authIntent = new Intent(SelectionActivity.this, FarmerLoginActivity.class);
                startActivity(authIntent);
               // finish();
                break;

            case R.id.dealer_cv:
                Intent authIntent1 = new Intent(SelectionActivity.this,DealerLoginActivity.class);
                startActivity(authIntent1);
               // finish();
                break;
        }



    }

    @Override
    public void onBackPressed() {
        finish();
    }

    private  boolean checkAndRequestPermissions() {
        int permissionSendMessage = ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS);
        int locationPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (locationPermission != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (permissionSendMessage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]),REQUEST_ID_MULTIPLE_PERMISSIONS);
            return false;
        }
        return true;
    }
}