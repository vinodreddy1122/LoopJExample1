package com.vsmart.farmengineer.activities;

import android.app.Activity;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.view.Window;

import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.useractivites.FarmerProductsActivity;
import com.vsmart.farmengineer.utils.PrefManager;

public class SplashActivity extends Activity {
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Window window = getWindow();
        window.setFormat(PixelFormat.RGBA_8888);
    }
    /** Called when the activity is first created. */
    Thread splashTread;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        StartAnimations();
    }
    private void StartAnimations() {



        splashTread = new Thread() {
            @Override
            public void run() {
                try {
                    int waited = 0;
                    // Splash screen pause time
                    while (waited < 3500) {
                        sleep(100);
                        waited += 100;
                    }
                    /*Intent intent = new Intent(SplashActivity.this,
                            SelectionActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                    startActivity(intent);
                    SplashActivity.this.finish();*/

                    if (PrefManager.getfe_vendor_id(SplashActivity.this, "fe_vendor_id").isEmpty() && PrefManager.getfe_users_id(SplashActivity.this, "fe_users_id").isEmpty()) {
                        Intent intent = new Intent(SplashActivity.this, SelectionActivity.class);
                        startActivity(intent);
                        finish();
                    }else {
                        if (PrefManager.getuser_type(SplashActivity.this, "user_type").equals("user"))
                        {
                            Intent intent = new Intent(SplashActivity.this, FarmerProductsActivity.class);
                            startActivity(intent);
                            finish();
                        }
                        else {
                            Intent intent = new Intent(SplashActivity.this, CategoryActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    }
                } catch (InterruptedException e) {
                    // do nothing
                } finally {
                    SplashActivity.this.finish();
                }

            }
        };
        splashTread.start();

    }

}

