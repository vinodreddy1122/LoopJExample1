package com.vsmart.farmengineer.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.activities.GetProductsById;
import com.vsmart.farmengineer.activities.MainActivity;
import com.vsmart.farmengineer.models.CategoriesHelper;
import com.vsmart.farmengineer.models.TypesHelper;

import java.util.List;

public class CategoriesAdapter extends RecyclerView.Adapter<CategoriesAdapter.ViewHolder> {

    List<CategoriesHelper> data;


    LayoutInflater inflter;
    Context context;
    private String catID;





    public CategoriesAdapter(List<CategoriesHelper> itemPojos,Context activity,String catID) {
        this.context = activity;
        this.data = itemPojos;
        this.catID = catID;


    }


    @NonNull
    @Override
    public CategoriesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.item_categories, parent, false);
        //return new HostelRecentlyAdapter.Business_head_list (itemView);
        // token = new PreferenceManager(context).getString(USER_TOKEN);
        return new CategoriesAdapter.ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoriesAdapter.ViewHolder holder, final int position) {
        final CategoriesHelper typesModel = data.get(position);

        holder.categoryName.setText(typesModel.getCat_name());

        Glide.with(context)
                .load("https://farm.smartmindsteam.com"+typesModel.getCat_img())
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.drawable.placeholder)
                .into(holder.categoryImage);


        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(context, GetProductsById.class);
                intent.putExtra("fe_cat_id",typesModel.getFe_cat_id());
                intent.putExtra("fe_cat_name",typesModel.getCat_name());
                intent.putExtra("product_types_id",catID);
                context.startActivity(intent);
            }
        });
    }



    @Override
    public int getItemCount() {
        return data.size();
    }

    @Override
    public int getItemViewType(int position) {return position;}


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView categoryName;
        ImageView categoryImage;
        LinearLayout mainLayout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            categoryName = itemView.findViewById(R.id.categoryName);
            categoryImage = itemView.findViewById(R.id.categoryImage);
            mainLayout = itemView.findViewById(R.id.mainLayout);

        }
    }





}