package com.vsmart.farmengineer.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.activities.GetProductsById;
import com.vsmart.farmengineer.activities.GetProductsByIdFullView;
import com.vsmart.farmengineer.activities.MainActivity;
import com.vsmart.farmengineer.models.GetProductsByIdHelper;
import com.vsmart.farmengineer.models.TypesHelper;

import java.util.List;
import java.util.Random;

public class GetProductsByIdAdapter extends RecyclerView.Adapter<GetProductsByIdAdapter.ViewHolder> {

    List<GetProductsByIdHelper> data;


    LayoutInflater inflter;
    Context context;
    private String token;
    private String feCatId,productsTypesID;





    public GetProductsByIdAdapter(List<GetProductsByIdHelper> itemPojos,Context activity,String feCatId,String productsTypesID) {
        this.context = activity;
        this.data = itemPojos;
        this.feCatId = feCatId;
        this.productsTypesID = productsTypesID;


    }


    @NonNull
    @Override
    public GetProductsByIdAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.item_products_by_id, parent, false);
        //return new HostelRecentlyAdapter.Business_head_list (itemView);
        // token = new PreferenceManager(context).getString(USER_TOKEN);
        return new GetProductsByIdAdapter.ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull GetProductsByIdAdapter.ViewHolder holder, final int position) {
        final GetProductsByIdHelper typesModel = data.get(position);

        holder.brand_name.setText(typesModel.getBrand_name());
        holder.models_name.setText(typesModel.getModels_name());
        holder.location.setText(typesModel.getLocation());


        Random r = new Random();
        int red=r.nextInt(255 - 0 + 1)+0;
        int green=r.nextInt(255 - 0 + 1)+0;
        int blue=r.nextInt(255 - 0 + 1)+0;

        GradientDrawable draw = new GradientDrawable();
        draw.setShape(GradientDrawable.OVAL);
        draw.setColor(Color.rgb(red,green,blue));
        holder.card_line.setBackgroundColor(Color.rgb(red,green,blue));

        Glide.with(context)
                .load("https://farm.smartmindsteam.com"+typesModel.getProduct_img())
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.drawable.placeholder)
                .into(holder.categoryImage);

        holder.card_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(context, GetProductsByIdFullView.class);
                intent.putExtra("brand_name",typesModel.getBrand_name());
                intent.putExtra("Product_img",typesModel.getProduct_img());
                intent.putExtra("models_name",typesModel.getModels_name());
                intent.putExtra("location",typesModel.getLocation());
                intent.putExtra("productsTypesID",productsTypesID);
                intent.putExtra("feCatId",feCatId);
                intent.putExtra("landmark",typesModel.getLand_mark());
                intent.putExtra("hours",typesModel.getHours());
                intent.putExtra("month",typesModel.getMonth());
                intent.putExtra("year",typesModel.getYear());
                intent.putExtra("price",typesModel.getPrice());
                intent.putExtra("RegistrationNo",typesModel.getRegistration_no());
                intent.putExtra("fe_product_id",typesModel.getFe_product_id());
                context.startActivity(intent);
            }
        });
    }



    @Override
    public int getItemCount() {
        return data.size();
    }

    @Override
    public int getItemViewType(int position) {return position;}


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView brand_name,models_name,location;
        ImageView categoryImage;
        CardView card_view;
        View card_line;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            brand_name = itemView.findViewById(R.id.brand_name);
            models_name = itemView.findViewById(R.id.models_name);
            location = itemView.findViewById(R.id.location);
            categoryImage = itemView.findViewById(R.id.categoryImage);
            card_view = itemView.findViewById(R.id.card_view);
            card_line = itemView.findViewById(R.id.card_line);

        }
    }





}
