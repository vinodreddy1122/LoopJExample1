package com.vsmart.farmengineer.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.activities.MainActivity;
import com.vsmart.farmengineer.models.TypesHelper;

import java.util.List;

public class TypesAdapter extends RecyclerView.Adapter<TypesAdapter.ViewHolder> {

    List<TypesHelper> data;


    LayoutInflater inflter;
    Context context;
    private String token;




    public TypesAdapter(List<TypesHelper> itemPojos,Context activity) {
        this.context = activity;
        this.data = itemPojos;


    }


    @NonNull
    @Override
    public TypesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.layout_type_disclaimer, parent, false);
        //return new HostelRecentlyAdapter.Business_head_list (itemView);
        // token = new PreferenceManager(context).getString(USER_TOKEN);
        return new TypesAdapter.ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TypesAdapter.ViewHolder holder, final int position) {
        final TypesHelper typesModel = data.get(position);

        holder.type_text_tv.setText(typesModel.getProduct_type_name());
        holder.type_id_cv.setBackgroundColor(Color.parseColor(typesModel.getColor_code()));
        /*try {
            Picasso.get()
                    .load(menuModel.getImage())
                    .placeholder(R.drawable.no_image)
                    .networkPolicy(NetworkPolicy.NO_CACHE)
                    .memoryPolicy(MemoryPolicy.NO_CACHE)
                    .into(holder.menu_item_image);
        }
        catch (Exception e){
            e.printStackTrace();
        }*/

        holder.type_id_cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, MainActivity.class);
                intent.putExtra("cat_id", typesModel.getProduct_types_id());
                //intent.putExtra("type", "u");

                context.startActivity(intent);
            }
        });





    }



    @Override
    public int getItemCount() {
        return data.size();
    }

    @Override
    public int getItemViewType(int position) {return position;}


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView type_text_tv;
        CardView type_id_cv;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            type_text_tv = itemView.findViewById(R.id.type_text_tv);
            type_id_cv = itemView.findViewById(R.id.type_id_cv);

        }
    }





}