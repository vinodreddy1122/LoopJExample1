package com.vsmart.farmengineer.adapters;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.MySSLSocketFactory;
import com.loopj.android.http.RequestParams;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.activities.GetProductsById;
import com.vsmart.farmengineer.activities.GetProductsByIdFullView;
import com.vsmart.farmengineer.activities.MainActivity;
import com.vsmart.farmengineer.models.GetProductsByIdHelper;
import com.vsmart.farmengineer.models.TypesHelper;
import com.vsmart.farmengineer.useractivites.FarmerLoginActivity;
import com.vsmart.farmengineer.useractivites.FarmerProductsActivity;
import com.vsmart.farmengineer.utils.CheckNetwork;
import com.vsmart.farmengineer.utils.PrefManager;
import com.vsmart.farmengineer.utils.Urls;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.KeyStore;
import java.util.List;
import java.util.Random;

import cz.msebera.android.httpclient.Header;

public class UserEnquiriesAdapter extends RecyclerView.Adapter<UserEnquiriesAdapter.ViewHolder> {

    List<GetProductsByIdHelper> data;
    Context context;
    private ProgressDialog progressDialog;





    public UserEnquiriesAdapter(List<GetProductsByIdHelper> itemPojos,Context activity) {
        this.context = activity;
        this.data = itemPojos;


    }


    @NonNull
    @Override
    public UserEnquiriesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.item_user_enquiries, parent, false);
        //return new HostelRecentlyAdapter.Business_head_list (itemView);
        // token = new PreferenceManager(context).getString(USER_TOKEN);
        return new UserEnquiriesAdapter.ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull UserEnquiriesAdapter.ViewHolder holder, final int position) {
        final GetProductsByIdHelper typesModel = data.get(position);

        holder.brand_name.setText(typesModel.getBrand_name());
        holder.models_name.setText(typesModel.getModels_name());
        holder.location.setText("Location: "+typesModel.getLocation());
        holder.vendorName.setText("Owner Name: "+typesModel.getVendor_name());
        holder.createdDate.setText("Date: "+typesModel.getCreated_date());
        holder.price.setText("Rent(p/h): "+typesModel.getPrice()+" / "+typesModel.getHours()+" Hours");



        Glide.with(context)
                .load("https://farm.smartmindsteam.com"+typesModel.getProduct_img())
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.drawable.placeholder)
                .into(holder.categoryImage);


    }



    @Override
    public int getItemCount() {
        return data.size();
    }

    @Override
    public int getItemViewType(int position) {return position;}


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView brand_name,models_name,location,vendorName,createdDate,price;
        ImageView categoryImage;
        CardView card_view;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            brand_name = itemView.findViewById(R.id.brand_name);
            models_name = itemView.findViewById(R.id.models_name);
            location = itemView.findViewById(R.id.location);
            categoryImage = itemView.findViewById(R.id.categoryImage);
            card_view = itemView.findViewById(R.id.card_view);
            price = itemView.findViewById(R.id.price);
            vendorName = itemView.findViewById(R.id.vendorName);
            createdDate = itemView.findViewById(R.id.createdDate);

        }
    }

}
