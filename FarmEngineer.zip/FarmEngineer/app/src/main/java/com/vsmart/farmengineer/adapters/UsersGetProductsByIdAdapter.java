package com.vsmart.farmengineer.adapters;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.MySSLSocketFactory;
import com.loopj.android.http.RequestParams;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.activities.DealerLoginActivity;
import com.vsmart.farmengineer.activities.DealerProfileActivity;
import com.vsmart.farmengineer.activities.GetProductsById;
import com.vsmart.farmengineer.activities.GetProductsByIdFullView;
import com.vsmart.farmengineer.activities.MainActivity;
import com.vsmart.farmengineer.models.GetProductsByIdHelper;
import com.vsmart.farmengineer.models.TypesHelper;
import com.vsmart.farmengineer.useractivites.FarmerLoginActivity;
import com.vsmart.farmengineer.useractivites.FarmerProductsActivity;
import com.vsmart.farmengineer.utils.CheckNetwork;
import com.vsmart.farmengineer.utils.PrefManager;
import com.vsmart.farmengineer.utils.Urls;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.KeyStore;
import java.util.List;
import java.util.Random;

import cz.msebera.android.httpclient.Header;

public class UsersGetProductsByIdAdapter extends RecyclerView.Adapter<UsersGetProductsByIdAdapter.ViewHolder> {

    List<GetProductsByIdHelper> data;
    Context context;
    private ProgressDialog progressDialog;



    public UsersGetProductsByIdAdapter(List<GetProductsByIdHelper> itemPojos,Context activity) {
        this.context = activity;
        this.data = itemPojos;


    }


    @NonNull
    @Override
    public UsersGetProductsByIdAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.item_user_products_by_id, parent, false);
        //return new HostelRecentlyAdapter.Business_head_list (itemView);
        // token = new PreferenceManager(context).getString(USER_TOKEN);
        return new UsersGetProductsByIdAdapter.ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull UsersGetProductsByIdAdapter.ViewHolder holder, final int position) {
        final GetProductsByIdHelper typesModel = data.get(position);

        holder.brand_name.setText(typesModel.getBrand_name());
         holder.models_name.setText(typesModel.getModels_name());
     //   holder.price.setText("\u20B9"+typesModel.getPrice());

        holder.owner_name.setText(typesModel.getOwner());
        holder.location.setText(typesModel.getLocation());


        if (typesModel.getProduct_types_id().equals("1")) {
            holder.price.setText(typesModel.getPrice());
            holder.hoursCount.setText(" / " + typesModel.getHours() + " hrs");
            holder.textStatus.setText("Rent");
            holder.textStatus.setTextColor(Color.parseColor("#A41E1D"));
        }
        else{
            holder.price.setText(typesModel.getPrice());
            holder.hoursCount.setVisibility(View.GONE);
            holder.textStatus.setText("Buy");
            holder.textStatus.setTextColor(Color.parseColor("#3A5F0B"));
        }



    /*    Random r = new Random();
        int red=r.nextInt(255 - 0 + 1)+0;
        int green=r.nextInt(255 - 0 + 1)+0;
        int blue=r.nextInt(255 - 0 + 1)+0;

        GradientDrawable draw = new GradientDrawable();
        draw.setShape(GradientDrawable.OVAL);
        draw.setColor(Color.rgb(red,green,blue));
        holder.card_line.setBackgroundColor(Color.rgb(red,green,blue));*/



        Glide.with(context)
                .load("https://farm.smartmindsteam.com"+typesModel.getProduct_img())
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.drawable.placeholder)
                .into(holder.categoryImage);


        holder.enquiryCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final AlertDialog.Builder builder = new AlertDialog.Builder(context, R.style.AppCompatAlertDialogStyle);
                builder.setTitle("Are you sure want to Enquiry?");
              //  builder.setIcon(R.drawable.logout_icon_png);

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                       init(typesModel.getFe_product_id(),typesModel.getFe_vendor_id(),typesModel.getProduct_types_id());

                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }

                });
                AlertDialog dialog = builder.create();
                dialog.show();

               // init(typesModel.getFe_product_id(),typesModel.getFe_vendor_id(),typesModel.getProduct_types_id());
            }
        });

       /* holder.card_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(context, GetProductsByIdFullView.class);
                intent.putExtra("brand_name",typesModel.getBrand_name());
                intent.putExtra("Product_img",typesModel.getProduct_img());
                intent.putExtra("models_name",typesModel.getModels_name());
                intent.putExtra("location",typesModel.getLocation());
                intent.putExtra("productsTypesID",productsTypesID);
                intent.putExtra("feCatId",feCatId);
                intent.putExtra("landmark",typesModel.getLand_mark());
                intent.putExtra("hours",typesModel.getHours());
                intent.putExtra("month",typesModel.getMonth());
                intent.putExtra("year",typesModel.getYear());
                intent.putExtra("price",typesModel.getPrice());
                intent.putExtra("RegistrationNo",typesModel.getRegistration_no());
                intent.putExtra("fe_product_id",typesModel.getFe_product_id());
                context.startActivity(intent);
            }
        });*/
    }



    @Override
    public int getItemCount() {
        return data.size();
    }

    @Override
    public int getItemViewType(int position) {return position;}


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView brand_name,price,owner_name,location,models_name,textStatus,hoursCount;
        ImageView categoryImage;
        CardView card_view;
        TextView enquiryCardView;
   //  View card_line;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            brand_name = itemView.findViewById(R.id.brand_name);
            models_name = itemView.findViewById(R.id.models_name);
            owner_name = itemView.findViewById(R.id.owner_name);
            location = itemView.findViewById(R.id.location);
           // models_name = itemView.findViewById(R.id.models_name);
            price = itemView.findViewById(R.id.price);
            categoryImage = itemView.findViewById(R.id.categoryImage);
            card_view = itemView.findViewById(R.id.card_view);
            enquiryCardView = itemView.findViewById(R.id.enquiryCardView);
            textStatus = itemView.findViewById(R.id.textStatus);
            hoursCount = itemView.findViewById(R.id.hoursCount);
    //    card_line = itemView.findViewById(R.id.card_line);

        }
    }


    private void init(String fe_product_id,String fe_vendor_id,String product_type_id) {

        RequestParams params = new RequestParams();
        params.put("action", "addenquirydata");
        params.put("fe_product_id", fe_product_id);
        params.put("fe_vendor_id", fe_vendor_id);
        params.put("product_type_id", product_type_id);

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("Authorization","Bearer "+PrefManager.getUserToken(context, "token"));
        client.addHeader("Content-Type","application/x-www-form-urlencoded");

        if (CheckNetwork.isInternetAvailable(context)) {
            try {
                KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
                trustStore.load(null, null);
                MySSLSocketFactory sf = new MySSLSocketFactory(trustStore);
                sf.setHostnameVerifier(MySSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
                client.setSSLSocketFactory(sf);
            } catch (Exception e) {
            }
            client.post(Urls.userbaseUrl,params, new AsyncHttpResponseHandler() {


                @Override
                public void onStart() {
                    // called before request is started
                    progressDialog = new ProgressDialog(context);
                    progressDialog.setMessage("Loading...");
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] response) {
                    // called when response HTTP status is "200 OK"
                    try {
                        JSONObject jsonObject = new JSONObject(new String(response));


                        if (jsonObject.getString("statusCode").equalsIgnoreCase("1")){


                            Toast.makeText(context, jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                           // ((Activity)context).recreate();

                            // progressDialog.dismiss();
                        } else {
                            Toast.makeText(context, jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        progressDialog.dismiss();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e) {
                    Toast.makeText(context,"Try Again later",Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            });

        } else{
            Toast.makeText(context, context.getString(R.string.noInternetText), Toast.LENGTH_SHORT).show();
            /*Snackbar snackbar1 = Snackbar.make(coordinatorLayout, R.string.noInternetText, Snackbar.LENGTH_SHORT);
            snackbar1.show();*/
        }
    }


}
