package com.vsmart.farmengineer.models;

public class CategoriesHelper {

    private String fe_cat_id,cat_name,cat_img;

    public String getFe_cat_id() {
        return fe_cat_id;
    }

    public void setFe_cat_id(String fe_cat_id) {
        this.fe_cat_id = fe_cat_id;
    }

    public String getCat_name() {
        return cat_name;
    }

    public void setCat_name(String cat_name) {
        this.cat_name = cat_name;
    }

    public String getCat_img() {
        return cat_img;
    }

    public void setCat_img(String cat_imgl) {
        this.cat_img = cat_imgl;
    }
}
