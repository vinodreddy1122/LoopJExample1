package com.vsmart.farmengineer.models;

public class GetProductsByIdHelper {
    private String cat_name,brand_name,models_name,product_types_id,product_condition,location,land_mark,hours,month,year,price,registration_no,product_img,fe_product_id,fe_vendor_id,vendor_name,created_date,owner,fe_name,fe_mobile,fe_email;

    public String getFe_name() {
        return fe_name;
    }

    public void setFe_name(String fe_name) {
        this.fe_name = fe_name;
    }

    public String getFe_mobile() {
        return fe_mobile;
    }

    public void setFe_mobile(String fe_mobile) {
        this.fe_mobile = fe_mobile;
    }

    public String getFe_email() {
        return fe_email;
    }

    public void setFe_email(String fe_email) {
        this.fe_email = fe_email;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getCreated_date() {
        return created_date;
    }

    public void setCreated_date(String created_date) {
        this.created_date = created_date;
    }

    public String getVendor_name() {
        return vendor_name;
    }

    public void setVendor_name(String vendor_name) {
        this.vendor_name = vendor_name;
    }
    public String getFe_vendor_id() {
        return fe_vendor_id;
    }

    public void setFe_vendor_id(String fe_vendor_id) {
        this.fe_vendor_id = fe_vendor_id;
    }

    public String getFe_product_id() {
        return fe_product_id;
    }

    public void setFe_product_id(String fe_product_id) {
        this.fe_product_id = fe_product_id;
    }

    public String getProduct_img() {
        return product_img;
    }

    public void setProduct_img(String product_img) {
        this.product_img = product_img;
    }

    public String getCat_name() {
        return cat_name;
    }

    public void setCat_name(String cat_name) {
        this.cat_name = cat_name;
    }

    public String getBrand_name() {
        return brand_name;
    }

    public void setBrand_name(String brand_name) {
        this.brand_name = brand_name;
    }

    public String getModels_name() {
        return models_name;
    }

    public void setModels_name(String models_name) {
        this.models_name = models_name;
    }

    public String getProduct_types_id() {
        return product_types_id;
    }

    public void setProduct_types_id(String product_types_id) {
        this.product_types_id = product_types_id;
    }

    public String getProduct_condition() {
        return product_condition;
    }

    public void setProduct_condition(String product_condition) {
        this.product_condition = product_condition;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getLand_mark() {
        return land_mark;
    }

    public void setLand_mark(String land_mark) {
        this.land_mark = land_mark;
    }

    public String getHours() {
        return hours;
    }

    public void setHours(String hours) {
        this.hours = hours;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getRegistration_no() {
        return registration_no;
    }

    public void setRegistration_no(String registration_no) {
        this.registration_no = registration_no;
    }
}
