package com.vsmart.farmengineer.models;

public class TypesHelper {

    private String product_types_id,product_type_name,color_code;

    public String getProduct_types_id() {
        return product_types_id;
    }

    public void setProduct_types_id(String product_types_id) {
        this.product_types_id = product_types_id;
    }

    public String getProduct_type_name() {
        return product_type_name;
    }

    public void setProduct_type_name(String product_type_name) {
        this.product_type_name = product_type_name;
    }

    public String getColor_code() {
        return color_code;
    }

    public void setColor_code(String color_code) {
        this.color_code = color_code;
    }
}
