package com.vsmart.farmengineer.useractivites;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


import org.json.JSONException;
import org.json.JSONObject;

import java.security.KeyStore;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.MySSLSocketFactory;
import com.loopj.android.http.RequestParams;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.activities.DealerLoginActivity;
import com.vsmart.farmengineer.activities.ProductTypesActivity;
import com.vsmart.farmengineer.utils.CheckNetwork;
import com.vsmart.farmengineer.utils.PrefManager;
import com.vsmart.farmengineer.utils.Urls;

import cz.msebera.android.httpclient.Header;



public class FarmerLoginActivity extends AppCompatActivity implements View.OnFocusChangeListener {

    AppCompatButton signButton;
    EditText userid_et,password_et;
    ProgressDialog progressDialog;
    TextView signup_tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_login);


        checkLocationPermission();
        userid_et = findViewById(R.id.userid_et);
        password_et = findViewById(R.id.password_et);

        userid_et.setOnFocusChangeListener(this);
        password_et.setOnFocusChangeListener(this);

        signup_tv = findViewById(R.id.signup_tv);

        signButton = (AppCompatButton) findViewById(R.id.signin_cv);
    //    empId.setText(PrefManager.getEmpCode(FarmerLoginActivity.this, "username"));
    //    password.setText(PrefManager.getPassword(FarmerLoginActivity.this, "password"));


        signup_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FarmerLoginActivity.this,FarmerRegistationActivity.class);
                startActivity(intent);
            }
        });


        signButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (userid_et.getText().toString().isEmpty()){
                    userid_et.setError("Please Enter Employee Id");
                    return;
                }

                if (password_et.getText().toString().isEmpty()){
                    password_et.setError("Please Enter Password");
                    return;
                }

                loginData(userid_et.getText().toString(),password_et.getText().toString());
            }
        });

    }

    private void loginData(String mobileString,String passwordString) {

        RequestParams params = new RequestParams();
        params.put("action", "userlogin");
        params.put("mobile", mobileString);
        params.put("password", passwordString);

       /* AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("action","userlogin");*/

        if (CheckNetwork.isInternetAvailable(FarmerLoginActivity.this)) {
            AsyncHttpClient client = new AsyncHttpClient();
            try {
                KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
                trustStore.load(null, null);
                MySSLSocketFactory sf = new MySSLSocketFactory(trustStore);
                sf.setHostnameVerifier(MySSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
                client.setSSLSocketFactory(sf);
            } catch (Exception e) {
            }
            client.post(Urls.userbaseUrl,params, new AsyncHttpResponseHandler() {


                @Override
                public void onStart() {
                    // called before request is started
                    progressDialog = new ProgressDialog(FarmerLoginActivity.this);
                    progressDialog.setMessage("SignIn...");
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] response) {
                    // called when response HTTP status is "200 OK"
                    try {
                        JSONObject jsonObject = new JSONObject(new String(response));


                        if (jsonObject.getString("statusCode").equalsIgnoreCase("1")){
                            PrefManager.setUserToken(FarmerLoginActivity.this, "token", jsonObject.getString("token"));
                            JSONObject responseObject = jsonObject.getJSONObject("response");

                            Log.v("status", responseObject.toString());
                            if (jsonObject.getString("statusCode").equalsIgnoreCase("1")) {

                                PrefManager.setfe_users_id(FarmerLoginActivity.this, "fe_users_id", responseObject.getString("fe_users_id"));
                                PrefManager.setfe_name(FarmerLoginActivity.this, "fe_name", responseObject.getString("fe_name"));
                                PrefManager.setfe_email(FarmerLoginActivity.this, "fe_email", responseObject.getString("fe_email"));
                                PrefManager.setfe_mobile(FarmerLoginActivity.this, "fe_mobile", responseObject.getString("fe_mobile"));
                                PrefManager.setuser_type(FarmerLoginActivity.this, "user_type", responseObject.getString("user_type"));

                                Intent intent = new Intent(FarmerLoginActivity.this, FarmerProductsActivity.class);
                                startActivity(intent);
                                finish();
                                progressDialog.dismiss();
                            }
                            // progressDialog.dismiss();
                        } else {
                             Toast.makeText(FarmerLoginActivity.this, jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                           /* Snackbar snackbar1 = Snackbar.make(coordinatorLayout, "Invalid Username/Password", Snackbar.LENGTH_SHORT);
                            snackbar1.show();*/
                            //progressDialog.dismiss();
                            progressDialog.dismiss();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        //progressDialog.dismiss();
                        progressDialog.dismiss();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e) {
                    // progressDialog.dismiss();
                    Toast.makeText(FarmerLoginActivity.this,"Try Again later",Toast.LENGTH_SHORT).show();
                   /* Snackbar snackbar1 = Snackbar.make(coordinatorLayout, "Try Again later", Snackbar.LENGTH_SHORT);
                    snackbar1.show();*/
                    progressDialog.dismiss();
                }
            });

        } else{
            Toast.makeText(FarmerLoginActivity.this, getString(R.string.noInternetText), Toast.LENGTH_SHORT).show();
            /*Snackbar snackbar1 = Snackbar.make(coordinatorLayout, R.string.noInternetText, Snackbar.LENGTH_SHORT);
            snackbar1.show();*/
        }
    }

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setTitle("Location Permission Needed")
                        .setMessage("This app needs the Location permission, please accept to use location functionality")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(FarmerLoginActivity.this,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {


                    }

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(this, "permission denied", Toast.LENGTH_LONG).show();
                }
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }


    public void hideKeyboard(View view) {
        InputMethodManager inputMethodManager =(InputMethodManager)getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    @Override
    public void onFocusChange(View view, boolean hasFocus) {
        if (!hasFocus) {
            hideKeyboard(view);
        }
    }
}