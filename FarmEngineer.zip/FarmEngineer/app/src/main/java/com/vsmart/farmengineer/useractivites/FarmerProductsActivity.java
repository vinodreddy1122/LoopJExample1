package com.vsmart.farmengineer.useractivites;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.activities.DealerEnquiriesActivity;
import com.vsmart.farmengineer.activities.DealerLoginActivity;
import com.vsmart.farmengineer.activities.DealerProfileActivity;
import com.vsmart.farmengineer.activities.MainActivity;
import com.vsmart.farmengineer.activities.SelectionActivity;
import com.vsmart.farmengineer.adapters.CategoriesAdapter;
import com.vsmart.farmengineer.adapters.TypesAdapter;
import com.vsmart.farmengineer.adapters.UserCategoriesAdapter;
import com.vsmart.farmengineer.models.CategoriesHelper;
import com.vsmart.farmengineer.models.TypesHelper;
import com.vsmart.farmengineer.utils.PrefManager;
import com.vsmart.farmengineer.utils.Urls;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import pl.droidsonroids.gif.GifImageView;

public class FarmerProductsActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    public DrawerLayout drawer;
    Toolbar toolbar;
    public NavigationView navigationView;
    RecyclerView categoriesRecycler;
    GifImageView progressBar;
    TextView nodataFound;
    List<CategoriesHelper> categoriesHelpers;
    private UserCategoriesAdapter recyclerviewViewadapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        getSupportActionBar().hide();

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(getResources().getString(R.string.app_name));

        categoriesRecycler = findViewById(R.id.categoriesRecycler);
        progressBar = findViewById(R.id.progressBar);
        nodataFound = findViewById(R.id.nodataFound);

        // RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(FarmerProductsActivity.this, RecyclerView.VERTICAL, false);
        // categoriesRecycler.setLayoutManager(layoutManager);
        categoriesRecycler.setLayoutManager(new GridLayoutManager(this, 2));

        categoriesRecycler.setHasFixedSize(true);
        categoriesRecycler.setNestedScrollingEnabled(false);

        init();


        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        toolbar.setNavigationIcon(R.drawable.ic_menu_black_24dp);

        navigationView = findViewById(R.id.nav_view);
        navigationView.setItemIconTintList(null);
        navigationView.setNavigationItemSelectedListener(this);

        View header = navigationView.getHeaderView(0);
        TextView userName = (TextView) header.findViewById(R.id.userName);
        userName.setText(PrefManager.getfe_name(FarmerProductsActivity.this, "fe_name"));

        LinearLayout headerLayout = header.findViewById(R.id.headerLayout);

        TextView userEmail = (TextView) header.findViewById(R.id.userEmail);
        userEmail.setText(PrefManager.getfe_email(FarmerProductsActivity.this, "fe_email"));

        headerLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FarmerProductsActivity.this, UserProfileActivity.class);
                startActivity(intent);
            }
        });



        navigationView.getMenu().getItem(0).setChecked(false);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        //Checking if the item is in checked state or not, if not make it in checked state
        if (item.isChecked())
            item.setChecked(false);
        else
            item.setChecked(true);

        //Closing drawer on item click
        drawer.closeDrawers();

        // Handle navigation view item clicks here.
        int id = item.getItemId();

        switch (id) {

            case R.id.enquiries:
                Intent intent = new Intent(FarmerProductsActivity.this, UserEnquiriresActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                return true;

            case R.id.logout:

                final AlertDialog.Builder builder = new AlertDialog.Builder(FarmerProductsActivity.this, R.style.AppCompatAlertDialogStyle);
                builder.setTitle("Are you sure want to logout?");
                builder.setIcon(R.drawable.logout_icon_png);

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        PrefManager.setfe_vendor_id(FarmerProductsActivity.this,"fe_users_id","");

                        Intent intent = new Intent(FarmerProductsActivity.this, SelectionActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }

                });
                AlertDialog dialog = builder.create();
                dialog.show();

                return true;

         /*   case R.id.rateUs:
                Intent viewIntent = new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=com.app.animalvideos"));
                startActivity(viewIntent);
                return true;

            case R.id.share:
                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_SUBJECT, "Animal Videos");
                    String sAux = "\nJallikattu Videos, Wild Animals, Funny Animals, Water Animals, etc. ...\n\n";
                    sAux = sAux + "https://play.google.com/store/apps/details?id=com.app.animalvideos \n\n";
                    i.putExtra(Intent.EXTRA_TEXT, sAux);
                    startActivity(Intent.createChooser(i, "choose one"));
                } catch(Exception e) {
                    //e.toString();
                }
                return true;

            case R.id.contact:
                Intent viewIntent1 = new Intent(HomeActivity.this,ContactUsActivity.class);
                startActivity(viewIntent1);
                return true;

            case R.id.moreApps:
                Intent viewIntent2 = new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/developer?id=RCR+GROUP"));
                startActivity(viewIntent2);
                return true;*/



            default:
                return true;
        }
    }

    private void init(){


        RequestParams params = new RequestParams();
        params.put("action", "getcategories");
        //params.put("cat_type_id", cat_id);

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("Authorization","Bearer "+PrefManager.getUserToken(FarmerProductsActivity.this, "token"));
        client.addHeader("Content-Type","application/x-www-form-urlencoded");

        client.post(Urls.userbaseUrl,params,new AsyncHttpResponseHandler() {


            public void onStart() {
                progressBar.setVisibility(View.VISIBLE);
                nodataFound.setVisibility(View.GONE);
                categoriesRecycler.setVisibility(View.GONE);

            }

            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                String s = new String(responseBody);
                try {

                    JSONObject jsonObject = new JSONObject(s);
                    JSONArray responseArray = jsonObject.getJSONArray("response");
                    if (jsonObject.getString("statusCode").equals("1")) {
                        categoriesHelpers = new ArrayList<CategoriesHelper>();
                        CategoriesHelper categoriesHelper;

                        for (int i = 0; i < responseArray.length(); i++) {
                            JSONObject jsonObject1 = responseArray.getJSONObject(i);

                            categoriesHelper = new CategoriesHelper();
                            categoriesHelper.setFe_cat_id(jsonObject1.getString("fe_cat_id"));
                            categoriesHelper.setCat_name(jsonObject1.getString("cat_name"));
                            categoriesHelper.setCat_img(jsonObject1.getString("cat_img"));


                            categoriesHelpers.add(categoriesHelper);

                        }

                        recyclerviewViewadapter = new UserCategoriesAdapter(categoriesHelpers, FarmerProductsActivity.this);
                        categoriesRecycler.setAdapter(recyclerviewViewadapter);
                        progressBar.setVisibility(View.GONE);
                        nodataFound.setVisibility(View.GONE);
                        categoriesRecycler.setVisibility(View.VISIBLE);

                    }else {
                        progressBar.setVisibility(View.GONE);
                        nodataFound.setVisibility(View.VISIBLE);
                        categoriesRecycler.setVisibility(View.GONE);
                    }

                }catch(JSONException e){
                    progressBar.setVisibility(View.GONE);
                    categoriesRecycler.setVisibility(View.GONE);
                    Toast.makeText(FarmerProductsActivity.this, "Loading failed...", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }


            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable e) {
                progressBar.setVisibility(View.GONE);
                categoriesRecycler.setVisibility(View.GONE);
                Toast.makeText(FarmerProductsActivity.this,"Loading failed...",Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setMessage("Are you sure you want to exit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Intent intent = new Intent(Intent.ACTION_MAIN);
                        intent.addCategory(Intent.CATEGORY_HOME);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                         finish();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }
}

