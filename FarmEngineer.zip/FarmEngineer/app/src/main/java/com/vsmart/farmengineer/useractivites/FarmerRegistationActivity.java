package com.vsmart.farmengineer.useractivites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.cardview.widget.CardView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.MySSLSocketFactory;
import com.loopj.android.http.RequestParams;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.activities.DealerLoginActivity;
import com.vsmart.farmengineer.activities.ProductTypesActivity;
import com.vsmart.farmengineer.utils.CheckNetwork;
import com.vsmart.farmengineer.utils.PrefManager;
import com.vsmart.farmengineer.utils.Urls;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.KeyStore;

import cz.msebera.android.httpclient.Header;

import static com.vsmart.farmengineer.utils.Validations.getEditTextString;
import static com.vsmart.farmengineer.utils.Validations.isValidEmail;
import static com.vsmart.farmengineer.utils.Validations.isValidPhoneNumber;
import static com.vsmart.farmengineer.utils.Validations.setEditextError;

public class FarmerRegistationActivity extends AppCompatActivity {

    AppCompatButton signup_cv;
    EditText full_name_et,email_et,mobile_et,password_et;
    String full_name_str,email_str,mobile_str,password_str;
    TextView signin_tv;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_registation);

        signin_tv = findViewById(R.id.signin_tv);
        signup_cv = findViewById(R.id.signup_cv);
        full_name_et = findViewById(R.id.full_name_et);
        email_et = findViewById(R.id.email_et);
        mobile_et = findViewById(R.id.mobile_et);
        password_et = findViewById(R.id.password_et);

        signin_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FarmerRegistationActivity.this, DealerLoginActivity.class);
                startActivity(intent);
                finish();
            }
        });


        signup_cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isValid()) {
                    registerUser();
                }
            }
        });
    }

    private void registerUser() {

        RequestParams params = new RequestParams();
        params.put("action","userregistration");
        params.put("full_name",full_name_str);
        params.put("email", email_str);
        params.put("mobile", mobile_str);
        params.put("password", password_str);

       /* AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("action","userlogin");*/

        if (CheckNetwork.isInternetAvailable(FarmerRegistationActivity.this)) {
            AsyncHttpClient client = new AsyncHttpClient();
            try {
                KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
                trustStore.load(null, null);
                MySSLSocketFactory sf = new MySSLSocketFactory(trustStore);
                sf.setHostnameVerifier(MySSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
                client.setSSLSocketFactory(sf);
            } catch (Exception e) {
            }
            client.post(Urls.userbaseUrl,params, new AsyncHttpResponseHandler() {


                @Override
                public void onStart() {
                    // called before request is started
                    progressDialog = new ProgressDialog(FarmerRegistationActivity.this);
                    progressDialog.setMessage("SignIn...");
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] response) {
                    // called when response HTTP status is "200 OK"
                    try {
                        JSONObject jsonObject = new JSONObject(new String(response));


                        if (jsonObject.getString("statusCode").equalsIgnoreCase("1")){


                            Intent intent = new Intent(FarmerRegistationActivity.this, FarmerLoginActivity.class);
                            startActivity(intent);
                            finish();
                            progressDialog.dismiss();
                            Toast.makeText(FarmerRegistationActivity.this, "Please Login with new credentials", Toast.LENGTH_SHORT).show();
                           /* JSONObject responseObject = jsonObject.getJSONObject("response");

                            Log.v("status", responseObject.toString());
                            if (jsonObject.getString("status").equalsIgnoreCase("1")) {

                                PrefManager.setfe_users_id(FarmerRegistationActivity.this, "fe_users_id", responseObject.getString("fe_users_id"));
                                Intent intent = new Intent(FarmerRegistationActivity.this, ProductTypesActivity.class);
                                startActivity(intent);
                                finish();
                                progressDialog.dismiss();
                            }*/
                            // progressDialog.dismiss();
                        } else {
                            Toast.makeText(FarmerRegistationActivity.this, jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                           /* Snackbar snackbar1 = Snackbar.make(coordinatorLayout, "Invalid Username/Password", Snackbar.LENGTH_SHORT);
                            snackbar1.show();*/
                            //progressDialog.dismiss();
                            progressDialog.dismiss();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        //progressDialog.dismiss();
                        progressDialog.dismiss();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e) {
                    // progressDialog.dismiss();
                    Toast.makeText(FarmerRegistationActivity.this,"Try Again later",Toast.LENGTH_SHORT).show();
                   /* Snackbar snackbar1 = Snackbar.make(coordinatorLayout, "Try Again later", Snackbar.LENGTH_SHORT);
                    snackbar1.show();*/
                    progressDialog.dismiss();
                }
            });

        } else{
            Toast.makeText(FarmerRegistationActivity.this, getString(R.string.noInternetText), Toast.LENGTH_SHORT).show();
            /*Snackbar snackbar1 = Snackbar.make(coordinatorLayout, R.string.noInternetText, Snackbar.LENGTH_SHORT);
            snackbar1.show();*/
        }
    }

    private boolean isValid() {

        boolean valid = true;
        full_name_str = getEditTextString(full_name_et);
        email_str = getEditTextString(email_et);
        mobile_str = getEditTextString(mobile_et);
        password_str = getEditTextString(password_et);

        if(full_name_str.length()==0){
            valid=false;
            setEditextError(full_name_et,"Empty not allowed");
        }
        else if(full_name_str.length()<3){
            valid=false;
            setEditextError(full_name_et,"Please provide valid details");
        }
        else if(email_str.length()==0){
            valid=false;
            setEditextError(email_et,"Empty not allowed");
        }else if(email_str.length()<7){
            valid=false;
            setEditextError(email_et,"Please provide valid email");
        }else if(!isValidEmail(email_str)){
            valid=false;
            setEditextError(email_et,"Please provide valid email");
        }else if(mobile_str.length()==0){
            valid=false;
            setEditextError(mobile_et,"Empty not allowed");
        }else if(mobile_str.length()<10){
            valid=false;
            setEditextError(mobile_et,"Please provide valid mobile number");
        }
        else if(!isValidPhoneNumber(mobile_et)){
            valid=false;
            setEditextError(mobile_et,"Please provide valid mobile number");
        }else if(password_str.length()==0){
            valid=false;
            setEditextError(password_et,"Empty not allowed");
        }
        else if(password_str.length()<4){
            valid=false;
            setEditextError(password_et,"Minimum 4 characters needed");
        }


        return valid;

    }
}
