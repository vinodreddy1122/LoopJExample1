package com.vsmart.farmengineer.useractivites;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.MySSLSocketFactory;
import com.loopj.android.http.RequestParams;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.activities.DealerLoginActivity;
import com.vsmart.farmengineer.activities.SelectionActivity;
import com.vsmart.farmengineer.utils.CheckNetwork;
import com.vsmart.farmengineer.utils.PrefManager;
import com.vsmart.farmengineer.utils.Urls;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.KeyStore;

import cz.msebera.android.httpclient.Header;

public class UserProfileActivity extends AppCompatActivity {

    TextView userName,useremailId,usermobileNumber;
    RelativeLayout logoutFooter;
    ProgressDialog progressDialog;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_white_24);

        userName = findViewById(R.id.userName);
        useremailId = findViewById(R.id.useremailId);
        usermobileNumber = findViewById(R.id.usermobileNumber);
        logoutFooter = findViewById(R.id.logoutFooter);

      //  userName.setText(PrefManager.getfull_name(UserProfileActivity.this, "full_name"));
     //   useremailId.setText(PrefManager.getemail_id(UserProfileActivity.this, "email_id"));
     //   usermobileNumber.setText(PrefManager.getmobile_no(UserProfileActivity.this, "mobile_no"));

        logoutFooter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(UserProfileActivity.this, R.style.AppCompatAlertDialogStyle);
                builder.setTitle("Are you sure want to logout?");
                builder.setIcon(R.drawable.logout_icon_png);

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        PrefManager.setfe_vendor_id(UserProfileActivity.this,"fe_users_id","");

                        Intent intent = new Intent(UserProfileActivity.this, SelectionActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }

                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        profileData();

    }


    private void profileData() {

        RequestParams params = new RequestParams();
        params.put("action", "userprofile");
        params.put("fe_user_id", PrefManager.getfe_users_id(UserProfileActivity.this, "fe_users_id"));

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("Authorization","Bearer "+PrefManager.getUserToken(UserProfileActivity.this, "token"));
        client.addHeader("Content-Type","application/x-www-form-urlencoded");

        if (CheckNetwork.isInternetAvailable(UserProfileActivity.this)) {
            try {
                KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
                trustStore.load(null, null);
                MySSLSocketFactory sf = new MySSLSocketFactory(trustStore);
                sf.setHostnameVerifier(MySSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
                client.setSSLSocketFactory(sf);
            } catch (Exception e) {
            }
            client.post(Urls.userbaseUrl,params, new AsyncHttpResponseHandler() {


                @Override
                public void onStart() {
                    // called before request is started
                    progressDialog = new ProgressDialog(UserProfileActivity.this);
                    progressDialog.setMessage("Loading...");
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] response) {
                    // called when response HTTP status is "200 OK"
                    try {
                        JSONObject jsonObject = new JSONObject(new String(response));


                        if (jsonObject.getString("statusCode").equalsIgnoreCase("1")){
                            JSONObject responseObject = jsonObject.getJSONObject("response");

                            Log.v("status", responseObject.toString());
                            if (jsonObject.getString("statusCode").equalsIgnoreCase("1")) {


                                userName.setText(responseObject.getString("fe_name"));
                                useremailId.setText(responseObject.getString("fe_email"));
                                usermobileNumber.setText(responseObject.getString("fe_mobile"));

                                progressDialog.dismiss();
                            }
                            // progressDialog.dismiss();
                        } else {
                            Toast.makeText(UserProfileActivity.this, jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                           /* Snackbar snackbar1 = Snackbar.make(coordinatorLayout, "Invalid Username/Password", Snackbar.LENGTH_SHORT);
                            snackbar1.show();*/
                            //progressDialog.dismiss();
                            progressDialog.dismiss();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        //progressDialog.dismiss();
                        progressDialog.dismiss();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e) {
                    // progressDialog.dismiss();
                    Toast.makeText(UserProfileActivity.this,"Try Again later",Toast.LENGTH_SHORT).show();
                   /* Snackbar snackbar1 = Snackbar.make(coordinatorLayout, "Try Again later", Snackbar.LENGTH_SHORT);
                    snackbar1.show();*/
                    progressDialog.dismiss();
                }
            });

        } else{
            Toast.makeText(UserProfileActivity.this, getString(R.string.noInternetText), Toast.LENGTH_SHORT).show();
            /*Snackbar snackbar1 = Snackbar.make(coordinatorLayout, R.string.noInternetText, Snackbar.LENGTH_SHORT);
            snackbar1.show();*/
        }
    }
}

