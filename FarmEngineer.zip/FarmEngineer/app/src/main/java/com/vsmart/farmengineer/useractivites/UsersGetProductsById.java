package com.vsmart.farmengineer.useractivites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.vsmart.farmengineer.R;
import com.vsmart.farmengineer.adapters.TypesAdapter;
import com.vsmart.farmengineer.adapters.UsersGetProductsByIdAdapter;
import com.vsmart.farmengineer.models.GetProductsByIdHelper;
import com.vsmart.farmengineer.models.TypesHelper;
import com.vsmart.farmengineer.utils.PrefManager;
import com.vsmart.farmengineer.utils.Urls;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import pl.droidsonroids.gif.GifImageView;

public class UsersGetProductsById extends AppCompatActivity {

    RecyclerView types_recycler;
    List<GetProductsByIdHelper> GetProductsByIdHelpers;
    private UsersGetProductsByIdAdapter recyclerviewViewadapter;
    GifImageView progressBar;
    TextView nodataFound;
    Toolbar toolbar;
    TextView categoryName;
    String productsTypeId,CatID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users_get_products_by_id);



        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_white_24);

        categoryName = findViewById(R.id.categoryName);

        categoryName.setText(getIntent().getStringExtra("fe_cat_name"));


        types_recycler = findViewById(R.id.types_recycler);
        progressBar = findViewById(R.id.progressBar);
        nodataFound = findViewById(R.id.nodataFound);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(UsersGetProductsById.this, RecyclerView.VERTICAL, false);
        types_recycler.setLayoutManager(layoutManager);
        types_recycler.setHasFixedSize(true);
        types_recycler.setNestedScrollingEnabled(false);





        init(getIntent().getStringExtra("fe_cat_id"));
    }

    private void init(final String feCatId){


        RequestParams params = new RequestParams();
        params.put("action", "getproductlist");
        params.put("fe_cat_id", feCatId);

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("Authorization","Bearer "+PrefManager.getUserToken(UsersGetProductsById.this, "token"));
        client.addHeader("Content-Type","application/x-www-form-urlencoded");

        Log.v("paramsvalue", params.toString());

        client.post(Urls.userbaseUrl,params,new AsyncHttpResponseHandler() {


            public void onStart() {
                progressBar.setVisibility(View.VISIBLE);
                nodataFound.setVisibility(View.GONE);
                types_recycler.setVisibility(View.GONE);

            }

            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                String s = new String(responseBody);
                try {

                    JSONObject jsonObject = new JSONObject(s);

                    JSONArray responseArray = jsonObject.getJSONArray("response");

                    if (responseArray.length()>0) {
                        if (jsonObject.getString("statusCode").equals("1")) {
                            GetProductsByIdHelpers = new ArrayList<GetProductsByIdHelper>();
                            GetProductsByIdHelper GetProductsByIdHelper;

                            for (int i = 0; i < responseArray.length(); i++) {
                                JSONObject jsonObject1 = responseArray.getJSONObject(i);

                                GetProductsByIdHelper = new GetProductsByIdHelper();
                                GetProductsByIdHelper.setFe_product_id(jsonObject1.getString("fe_product_id"));
                                GetProductsByIdHelper.setFe_vendor_id(jsonObject1.getString("fe_vendor_id"));
                                GetProductsByIdHelper.setBrand_name(jsonObject1.getString("brand_name"));
                                GetProductsByIdHelper.setModels_name(jsonObject1.getString("models_name"));
                                GetProductsByIdHelper.setProduct_types_id(jsonObject1.getString("product_types_id"));
                                GetProductsByIdHelper.setProduct_condition(jsonObject1.getString("product_condition"));
                                GetProductsByIdHelper.setHours(jsonObject1.getString("hours"));
                                GetProductsByIdHelper.setMonth(jsonObject1.getString("month"));
                                GetProductsByIdHelper.setYear(jsonObject1.getString("year"));
                                GetProductsByIdHelper.setPrice(jsonObject1.getString("price"));
                                GetProductsByIdHelper.setProduct_img(jsonObject1.getString("product_img"));
                                GetProductsByIdHelper.setOwner(jsonObject1.getString("owner"));
                                GetProductsByIdHelper.setLocation(jsonObject1.getString("location"));


                                GetProductsByIdHelpers.add(GetProductsByIdHelper);

                            }

                            recyclerviewViewadapter = new UsersGetProductsByIdAdapter(GetProductsByIdHelpers, UsersGetProductsById.this);
                            types_recycler.setAdapter(recyclerviewViewadapter);
                            progressBar.setVisibility(View.GONE);
                            nodataFound.setVisibility(View.GONE);
                            types_recycler.setVisibility(View.VISIBLE);

                        } else {
                            progressBar.setVisibility(View.GONE);
                            nodataFound.setVisibility(View.VISIBLE);
                            types_recycler.setVisibility(View.GONE);
                        }
                    }else {
                        progressBar.setVisibility(View.GONE);
                        nodataFound.setVisibility(View.VISIBLE);
                        types_recycler.setVisibility(View.GONE);
                    }

                }catch(JSONException e){
                    progressBar.setVisibility(View.GONE);
                    types_recycler.setVisibility(View.GONE);
                    Toast.makeText(UsersGetProductsById.this, "Loading failed...", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }


            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable e) {
                progressBar.setVisibility(View.GONE);
                types_recycler.setVisibility(View.GONE);
                Toast.makeText(UsersGetProductsById.this,"Loading failed...",Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public void onBackPressed() {
        init(getIntent().getStringExtra("fe_cat_id"));
        super.onBackPressed();
    }
}