package com.vsmart.farmengineer.utils;

public class Urls {

    public static String baseUrl = "https://farm.smartmindsteam.com/modules/vendorModules/operations/vendor_operations.php";

    public static String userbaseUrl = "https://farm.smartmindsteam.com/modules/userModules/operations/user_operations.php";
}
